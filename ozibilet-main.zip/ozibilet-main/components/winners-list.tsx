"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Medal, Award, Gift, Crown } from "lucide-react"
import { motion } from "framer-motion"

interface Winner {
  id: string
  userName: string
  ticketNumber: string
  prize: string
  eventName: string
}

interface CompletedDraw {
  id: string
  eventName: string
  company: string
  completedDate: string
  winners: {
    id: string
    userName: string
    ticketNumber: string
    prize: number
    prizeDescription: string
    rank: number
  }[]
}

export function WinnersList() {
  const [completedDraws, setCompletedDraws] = useState<CompletedDraw[]>([])

  useEffect(() => {
    // Tamamlanan çekilişleri kontrol et
    const checkCompletedDraws = () => {
      const storedDraws = localStorage.getItem("completed_draws")
      if (storedDraws) {
        try {
          const draws = JSON.parse(storedDraws)
          setCompletedDraws(draws)
        } catch (error) {
          console.error("Tamamlanan çekilişler yüklenemedi:", error)
        }
      }
    }

    checkCompletedDraws()
    // Her 30 saniyede bir kontrol et
    const interval = setInterval(checkCompletedDraws, 30000)
    return () => clearInterval(interval)
  }, [])

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-600" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-500" />
      case 3:
        return <Award className="h-6 w-6 text-orange-600" />
      default:
        return <Gift className="h-6 w-6 text-purple-600" />
    }
  }

  if (completedDraws.length === 0) {
    return null
  }

  return (
    <div className="space-y-8">
      {completedDraws.map((draw) => (
        <Card key={draw.id} className="backdrop-blur-md bg-white/40 border-white/20 shadow-xl">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Crown className="h-8 w-8 text-yellow-600" />
              <CardTitle className="text-3xl font-bold bg-gradient-to-r from-yellow-600 via-orange-600 to-red-600 bg-clip-text text-transparent">
                {draw.eventName} - KAZANANLAR
              </CardTitle>
            </div>
            <CardDescription className="text-lg">
              Çekiliş Tarihi: {new Date(draw.completedDate).toLocaleDateString("tr-TR")} - {draw.winners.length} Kazanan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {draw.winners
                .sort((a, b) => b.prize - a.prize) // Büyükten küçüğe sırala
                .map((winner, index) => (
                  <motion.div
                    key={winner.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="flex items-center gap-4">
                      {getRankIcon(winner.rank)}
                      <div>
                        <h3 className="font-bold text-xl text-gray-800">{winner.userName}</h3>
                        <p className="text-sm text-gray-600">
                          Bilet Numarası:{" "}
                          <span className="font-mono font-bold text-blue-600">{winner.ticketNumber}</span>
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-green-600">{winner.prize.toLocaleString("tr-TR")} TL</div>
                      <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
                        {winner.prizeDescription}
                      </Badge>
                    </div>
                  </motion.div>
                ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
