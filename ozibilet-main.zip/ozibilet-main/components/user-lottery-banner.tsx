"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, Trophy, Sparkles, Gift, Heart, Target } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface UserLotteryStatus {
  isWinner: boolean
  prize?: string
  eventName?: string
  ticketNumber?: string
  message: string
}

export function UserLotteryBanner() {
  const [lotteryStatus, setLotteryStatus] = useState<UserLotteryStatus | null>(null)
  const [showBanner, setShowBanner] = useState(false)

  useEffect(() => {
    const checkUserLotteryStatus = () => {
      const userEmail = localStorage.getItem("userEmail")
      const storedWinners = localStorage.getItem("lottery_winners")

      if (!userEmail || !storedWinners) return

      try {
        const winners = JSON.parse(storedWinners)
        const userWin = winners.find(
          (winner: any) =>
            winner.userName.toLowerCase().includes(userEmail.split("@")[0].toLowerCase()) ||
            winner.userEmail === userEmail,
        )

        if (userWin) {
          setLotteryStatus({
            isWinner: true,
            prize: userWin.prize,
            eventName: userWin.eventName,
            ticketNumber: userWin.ticketNumber,
            message: `🎉 Tebrikler! ${userWin.prize} kazandınız! 🎉`,
          })
        } else {
          // Kullanıcı kazanmamış, motivasyonlu mesaj göster
          setLotteryStatus({
            isWinner: false,
            message: "Bu sefer olmadı ama vazgeçme! Bir sonraki çekilişte şansın daha yüksek olabilir! 💪",
          })
        }
        setShowBanner(true)
      } catch (error) {
        console.error("Çekiliş durumu kontrol edilemedi:", error)
      }
    }

    checkUserLotteryStatus()
  }, [])

  const closeBanner = () => {
    setShowBanner(false)
    setLotteryStatus(null)
  }

  if (!showBanner || !lotteryStatus) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="fixed top-20 right-4 z-50 max-w-sm"
      >
        <Card
          className={`${
            lotteryStatus.isWinner
              ? "bg-gradient-to-r from-green-400 via-emerald-500 to-teal-500"
              : "bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500"
          } border-white/30 shadow-2xl`}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                {lotteryStatus.isWinner ? (
                  <Trophy className="h-6 w-6 text-white animate-bounce" />
                ) : (
                  <Heart className="h-6 w-6 text-white animate-pulse" />
                )}
                <h3 className="text-lg font-bold text-white">
                  {lotteryStatus.isWinner ? "KAZANDIN!" : "Bir Dahaki Sefere!"}
                </h3>
              </div>
              <Button onClick={closeBanner} variant="ghost" size="sm" className="text-white hover:bg-white/20">
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="text-center">
              {lotteryStatus.isWinner ? (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2 }}
                  className="bg-white/90 rounded-lg p-4 mb-4"
                >
                  <div className="flex items-center justify-center mb-2">
                    <Gift className="h-8 w-8 text-yellow-600 mr-2" />
                    <div className="text-2xl font-bold text-gray-800">{lotteryStatus.prize}</div>
                  </div>
                  <div className="text-sm text-gray-600 mb-1">
                    Bilet: <span className="font-mono font-bold">{lotteryStatus.ticketNumber}</span>
                  </div>
                  <div className="text-xs text-gray-500">{lotteryStatus.eventName}</div>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2 }}
                  className="bg-white/90 rounded-lg p-4 mb-4"
                >
                  <div className="flex items-center justify-center mb-2">
                    <Target className="h-8 w-8 text-purple-600 mr-2" />
                    <div className="text-lg font-bold text-gray-800">Hedef: Bir Sonraki Çekiliş!</div>
                  </div>
                  <div className="text-sm text-gray-600">Daha fazla bilet = Daha yüksek şans! 🎯</div>
                </motion.div>
              )}

              <p className="text-white text-sm mb-4">{lotteryStatus.message}</p>

              {!lotteryStatus.isWinner && (
                <div className="flex items-center justify-center gap-2 text-white/80 text-xs">
                  <Sparkles className="h-4 w-4" />
                  <span>Yeni etkinliklere katılmaya devam et!</span>
                  <Sparkles className="h-4 w-4" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}
