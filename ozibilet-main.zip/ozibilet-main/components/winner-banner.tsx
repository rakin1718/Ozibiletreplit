"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, Trophy, Sparkles } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface Winner {
  id: string
  userName: string
  ticketNumber: string
  prize: string
  eventName: string
}

export function WinnerBanner() {
  const [winners, setWinners] = useState<Winner[]>([])
  const [showBanner, setShowBanner] = useState(false)

  useEffect(() => {
    const checkWinners = () => {
      const showWinnerBanner = localStorage.getItem("show_winner_banner")
      const storedWinners = localStorage.getItem("lottery_winners")

      if (showWinnerBanner === "true" && storedWinners) {
        const winnersData = JSON.parse(storedWinners)
        setWinners(winnersData)
        setShowBanner(true)
      }
    }

    checkWinners()
    const interval = setInterval(checkWinners, 5000)
    return () => clearInterval(interval)
  }, [])

  const closeBanner = () => {
    setShowBanner(false)
    localStorage.removeItem("show_winner_banner")
    localStorage.removeItem("lottery_winners")
  }

  if (!showBanner || winners.length === 0) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -100 }}
        className="fixed top-0 left-0 right-0 z-50 p-4"
      >
        <Card className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 border-yellow-300 shadow-2xl">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Trophy className="h-8 w-8 text-white animate-bounce" />
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  🎉 ÇEKİLİŞ SONUÇLARI AÇIKLANDI! 🎉
                  <Sparkles className="h-6 w-6 text-yellow-200 animate-pulse" />
                </h2>
              </div>
              <Button onClick={closeBanner} variant="ghost" size="sm" className="text-white hover:bg-white/20">
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
              {winners.map((winner, index) => (
                <motion.div
                  key={winner.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white/95 backdrop-blur-sm rounded-lg p-4 border border-yellow-200"
                >
                  <div className="text-center">
                    <div className="text-lg font-bold text-gray-800 mb-2">{winner.prize}</div>
                    <div className="text-blue-600 font-semibold mb-1">{winner.userName}</div>
                    <div className="text-sm text-gray-600 mb-1">
                      Bilet: <span className="font-mono font-bold">{winner.ticketNumber}</span>
                    </div>
                    <div className="text-xs text-gray-500">{winner.eventName}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="text-center">
              <p className="text-white text-sm">
                🎊 Tebrikler kazanan arkadaşımız! Ödülünüz için iletişime geçiniz. 🎊
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}
