"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Medal, Award, Star, Crown, Sparkles, Gift } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface BigWinner {
  id: string
  user_name: string
  ticket_number: string
  prize: string
  event_name: string
  created_at: string
  prizeAmount: number
}

export function BigWinnersShowcase() {
  const [bigWinners, setBigWinners] = useState<BigWinner[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchBigWinners = async () => {
      try {
        const response = await fetch("/api/lottery/results")
        const data = await response.json()

        if (response.ok && data.results && data.results.length > 0) {
          // API'den veri varsa onu kullan
          const bigWinnersOnly = data.results
            .map((winner: any) => ({
              ...winner,
              prizeAmount: Number.parseFloat(winner.prize.replace(/[^\d]/g, "")),
            }))
            .filter((winner: BigWinner) => winner.prizeAmount > 2000)
            .sort((a: BigWinner, b: BigWinner) => b.prizeAmount - a.prizeAmount)

          setBigWinners(bigWinnersOnly)
        } else {
          // API'den veri yoksa güncellenmiş sabit kazanan biletleri göster
          const staticWinners: BigWinner[] = [
            {
              id: "1",
              user_name: "ŞansCasino Üyesi",
              ticket_number: "89024968",
              prize: "50.000 TL",
              event_name: "ŞansCasino Büyük Çekiliş",
              created_at: new Date().toISOString(),
              prizeAmount: 50000,
            },
            {
              id: "2",
              user_name: "ŞansCasino Üyesi",
              ticket_number: "79707490",
              prize: "30.000 TL",
              event_name: "ŞansCasino Büyük Çekiliş",
              created_at: new Date().toISOString(),
              prizeAmount: 30000,
            },
            {
              id: "3",
              user_name: "ŞansCasino Üyesi",
              ticket_number: "93090064",
              prize: "15.000 TL",
              event_name: "ŞansCasino Büyük Çekiliş",
              created_at: new Date().toISOString(),
              prizeAmount: 15000,
            },
            {
              id: "4",
              user_name: "ŞansCasino Üyesi",
              ticket_number: "27717995",
              prize: "10.000 TL",
              event_name: "ŞansCasino Büyük Çekiliş",
              created_at: new Date().toISOString(),
              prizeAmount: 10000,
            },
            {
              id: "5",
              user_name: "ŞansCasino Üyesi",
              ticket_number: "33192366",
              prize: "5.000 TL",
              event_name: "ŞansCasino Büyük Çekiliş",
              created_at: new Date().toISOString(),
              prizeAmount: 5000,
            },
          ]
          setBigWinners(staticWinners)
        }
      } catch (error) {
        console.error("Büyük kazananlar yüklenirken hata:", error)
        // Hata durumunda da güncellenmiş sabit verileri göster
        const staticWinners: BigWinner[] = [
          {
            id: "1",
            user_name: "ŞansCasino Üyesi",
            ticket_number: "89024968",
            prize: "50.000 TL",
            event_name: "ŞansCasino Büyük Çekiliş",
            created_at: new Date().toISOString(),
            prizeAmount: 50000,
          },
          {
            id: "2",
            user_name: "ŞansCasino Üyesi",
            ticket_number: "79707490",
            prize: "30.000 TL",
            event_name: "ŞansCasino Büyük Çekiliş",
            created_at: new Date().toISOString(),
            prizeAmount: 30000,
          },
          {
            id: "3",
            user_name: "ŞansCasino Üyesi",
            ticket_number: "93090064",
            prize: "15.000 TL",
            event_name: "ŞansCasino Büyük Çekiliş",
            created_at: new Date().toISOString(),
            prizeAmount: 15000,
          },
          {
            id: "4",
            user_name: "ŞansCasino Üyesi",
            ticket_number: "27717995",
            prize: "10.000 TL",
            event_name: "ŞansCasino Büyük Çekiliş",
            created_at: new Date().toISOString(),
            prizeAmount: 10000,
          },
          {
            id: "5",
            user_name: "ŞansCasino Üyesi",
            ticket_number: "33192366",
            prize: "5.000 TL",
            event_name: "ŞansCasino Büyük Çekiliş",
            created_at: new Date().toISOString(),
            prizeAmount: 5000,
          },
        ]
        setBigWinners(staticWinners)
      } finally {
        setLoading(false)
      }
    }

    fetchBigWinners()
    const interval = setInterval(fetchBigWinners, 30000)
    return () => clearInterval(interval)
  }, [])

  const getRankIcon = (prizeAmount: number) => {
    if (prizeAmount >= 50000) return <Crown className="h-10 w-10 text-yellow-500" />
    if (prizeAmount >= 30000) return <Trophy className="h-9 w-9 text-yellow-600" />
    if (prizeAmount >= 15000) return <Medal className="h-8 w-8 text-gray-500" />
    if (prizeAmount >= 10000) return <Award className="h-8 w-8 text-orange-600" />
    if (prizeAmount >= 5000) return <Star className="h-7 w-7 text-purple-600" />
    return null
  }

  const getRankBadgeColor = (prizeAmount: number) => {
    if (prizeAmount >= 50000) return "bg-gradient-to-r from-yellow-400 to-yellow-600 text-white"
    if (prizeAmount >= 30000) return "bg-gradient-to-r from-yellow-500 to-orange-500 text-white"
    if (prizeAmount >= 15000) return "bg-gradient-to-r from-gray-400 to-gray-600 text-white"
    if (prizeAmount >= 10000) return "bg-gradient-to-r from-orange-400 to-orange-600 text-white"
    if (prizeAmount >= 5000) return "bg-gradient-to-r from-purple-400 to-purple-600 text-white"
    return "bg-gradient-to-r from-blue-400 to-blue-600 text-white"
  }

  const getRankTitle = (prizeAmount: number) => {
    if (prizeAmount >= 50000) return "🥇 BÜYÜK ÖDÜL"
    if (prizeAmount >= 30000) return "🥈 İKİNCİ ÖDÜL"
    if (prizeAmount >= 15000) return "🥉 ÜÇÜNCİ ÖDÜL"
    if (prizeAmount >= 10000) return "🏆 DÖRDÜNCÜ ÖDÜL"
    if (prizeAmount >= 5000) return "⭐ BEŞİNCİ ÖDÜL"
    return ""
  }

  if (loading) {
    return (
      <section id="big-winners-section" className="py-12">
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="text-gray-500 mt-4">Büyük kazananlar yükleniyor...</p>
        </div>
      </section>
    )
  }

  return (
    <section id="big-winners-section" className="py-12">
      <div className="text-center mb-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-center gap-3 mb-4"
        >
          <Sparkles className="h-8 w-8 text-yellow-500 animate-pulse" />
          <h2 className="text-4xl font-bold bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent">
            🏆 BÜYÜK KAZANANLAR 🏆
          </h2>
          <Sparkles className="h-8 w-8 text-yellow-500 animate-pulse" />
        </motion.div>
        <p className="text-lg text-orange-600 font-bold mb-2">ŞansCasino Çekiliş Sonuçları</p>
        <p className="text-base text-gray-700 font-medium">
          🎊 Şeffaflık için büyük ödül kazananlarımızı paylaşıyoruz! 🎊
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 max-w-7xl mx-auto">
        <AnimatePresence>
          {bigWinners.map((winner, index) => (
            <motion.div
              key={winner.id}
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -20 }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
            >
              <Card className="backdrop-blur-md bg-white/95 border-3 border-yellow-300 shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 hover:rotate-2 relative overflow-hidden">
                {/* Arka plan efekti */}
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-100/50 via-orange-100/50 to-red-100/50"></div>

                <CardHeader className="text-center pb-3 relative z-10">
                  <div className="flex items-center justify-center mb-3">{getRankIcon(winner.prizeAmount)}</div>
                  <CardTitle className="text-3xl font-bold text-gray-800 mb-3">{winner.prize}</CardTitle>
                  <Badge className={`${getRankBadgeColor(winner.prizeAmount)} font-bold text-sm px-4 py-2 shadow-lg`}>
                    {getRankTitle(winner.prizeAmount)}
                  </Badge>
                </CardHeader>

                <CardContent className="text-center relative z-10">
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-xl border-2 border-blue-200 mb-3 shadow-inner">
                    <p className="text-sm text-gray-600 mb-2 font-semibold">🎫 Kazanan Bilet:</p>
                    <p className="text-2xl font-mono font-bold text-blue-600 tracking-wider">{winner.ticket_number}</p>
                  </div>
                  <p className="text-xs text-gray-500 font-medium">
                    {new Date(winner.created_at).toLocaleDateString("tr-TR")}
                  </p>
                </CardContent>

                {/* Köşe süsü */}
                <div className="absolute top-2 right-2">
                  <div className="w-6 h-6 bg-yellow-400 rounded-full animate-ping opacity-75"></div>
                  <div className="absolute top-0 right-0 w-6 h-6 bg-yellow-500 rounded-full"></div>
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Şeffaflık mesajı */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="text-center mt-12"
      >
        <Card className="bg-gradient-to-r from-green-500 via-blue-600 to-purple-600 border-2 border-white/30 shadow-2xl max-w-4xl mx-auto">
          <CardContent className="p-6 text-center text-white">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Trophy className="h-8 w-8 text-yellow-300" />
              <h3 className="text-2xl font-bold">🎯 Şeffaflık Taahhüdümüz</h3>
              <Trophy className="h-8 w-8 text-yellow-300" />
            </div>

            <div className="space-y-3 text-lg">
              <p className="font-semibold">
                ✨ Tüm çekilişlerimiz <strong>tamamen şeffaf</strong> ve <strong>adil</strong> bir şekilde
                gerçekleştirilir!
              </p>
              <p>
                🎊 Büyük ödül kazananlarımızı herkesle paylaşarak <strong>güvenilirliğimizi</strong> kanıtlıyoruz.
              </p>
              <p className="text-yellow-200 font-bold">🚀 Siz de bir sonraki büyük kazanan olabilirsiniz!</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* 2000₺ kazananlar için ek mesaj */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2 }}
        className="text-center mt-8"
      >
        <Card className="bg-gradient-to-r from-orange-500 via-red-600 to-pink-600 border-2 border-white/30 shadow-2xl max-w-4xl mx-auto">
          <CardContent className="p-6 text-center text-white">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Gift className="h-8 w-8 text-yellow-300" />
              <h3 className="text-2xl font-bold">🎁 2.000 TL Kazananlar</h3>
              <Gift className="h-8 w-8 text-yellow-300" />
            </div>

            <div className="space-y-3 text-lg">
              <p className="font-semibold">
                🎊 <strong>10 kişi</strong> 2.000 TL ödül kazandı!
              </p>
              <p className="text-sm">
                📋 <strong>Kazanan Biletler:</strong> 56162266, 32549388, 73141479, 49209426, 72967992, 86291486,
                27452358, 97181015, 78399609, 72848225
              </p>
              <p>
                🔐 2.000 TL kazanan arkadaşlarımız <strong>hesaplarına giriş yaparak</strong> bilet numaralarını
                görebilirler.
              </p>
              <p className="text-yellow-200 font-bold text-xl">💰 Tebrikler kazanan arkadaşlarımız! 💰</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </section>
  )
}
