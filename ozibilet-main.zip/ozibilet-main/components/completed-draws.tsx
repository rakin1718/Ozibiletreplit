"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trophy, Medal, Award, Gift } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface CompletedDraw {
  id: string
  eventName: string
  company: string
  completedDate: string
  winners: {
    id: string
    userName: string
    ticketNumber: string
    prize: number
    prizeDescription: string
    rank: number
  }[]
}

export function CompletedDraws() {
  const [completedDraws, setCompletedDraws] = useState<CompletedDraw[]>([])
  const [selectedDraw, setSelectedDraw] = useState<CompletedDraw | null>(null)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    // Tamamlanan çekilişleri localStorage'dan al
    const checkCompletedDraws = () => {
      const storedDraws = localStorage.getItem("completed_draws")
      if (storedDraws) {
        try {
          const draws = JSON.parse(storedDraws)
          setCompletedDraws(draws)
        } catch (error) {
          console.error("Tamamlanan çekilişler yüklenemedi:", error)
        }
      }
    }

    checkCompletedDraws()
    // Her 30 saniyede bir kontrol et
    const interval = setInterval(checkCompletedDraws, 30000)
    return () => clearInterval(interval)
  }, [])

  const handleDrawClick = (draw: CompletedDraw) => {
    setSelectedDraw(draw)
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedDraw(null)
  }

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-600" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-500" />
      case 3:
        return <Award className="h-6 w-6 text-orange-600" />
      default:
        return <Gift className="h-6 w-6 text-purple-600" />
    }
  }

  if (completedDraws.length === 0) {
    return null
  }

  return (
    <>
      <Card className="backdrop-blur-md bg-white/40 border-white/20 shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl text-gray-800 flex items-center gap-2">
            <Trophy className="h-6 w-6 text-yellow-600" />
            Sonuçlanan Çekilişler
          </CardTitle>
          <CardDescription>Tamamlanan çekilişlerin sonuçlarını görüntüleyin</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {completedDraws.map((draw) => (
              <Card
                key={draw.id}
                className="cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:scale-105 bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200"
                onClick={() => handleDrawClick(draw)}
              >
                <CardContent className="p-4">
                  <div className="text-center">
                    <h3 className="font-bold text-lg text-gray-800 mb-2">{draw.eventName}</h3>
                    <Badge className="bg-green-100 text-green-800 border-green-200 mb-2">Tamamlandı</Badge>
                    <p className="text-sm text-gray-600 mb-2">{draw.winners.length} kazanan belirlendi</p>
                    <p className="text-xs text-gray-500">{new Date(draw.completedDate).toLocaleDateString("tr-TR")}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Modal */}
      <AnimatePresence>
        {showModal && selectedDraw && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={closeModal}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-lg max-w-4xl w-full max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-gray-800">{selectedDraw.eventName} - Kazananlar</h2>
                  <Button onClick={closeModal} variant="outline">
                    Kapat
                  </Button>
                </div>

                <div className="space-y-4">
                  {selectedDraw.winners
                    .sort((a, b) => b.prize - a.prize) // Büyükten küçüğe sırala
                    .map((winner, index) => (
                      <motion.div
                        key={winner.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200"
                      >
                        <div className="flex items-center gap-4">
                          {getRankIcon(winner.rank)}
                          <div>
                            <h3 className="font-bold text-lg text-gray-800">{winner.userName}</h3>
                            <p className="text-sm text-gray-600">
                              Bilet: <span className="font-mono font-bold">{winner.ticketNumber}</span>
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-green-600">
                            {winner.prize.toLocaleString("tr-TR")} TL
                          </div>
                          <div className="text-sm text-gray-600">{winner.prizeDescription}</div>
                        </div>
                      </motion.div>
                    ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
