"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Trophy, Medal, Award, Gift, Crown, Star, Sparkles, Bell } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface Winner {
  id: string
  user_name: string
  ticket_number: string
  prize: string
  event_name: string
  created_at: string
  prizeAmount: number
}

export function WinnersAnnouncement() {
  const [winners, setWinners] = useState<Winner[]>([])
  const [loading, setLoading] = useState(true)
  const [showAll, setShowAll] = useState(false)

  useEffect(() => {
    const fetchWinners = async () => {
      try {
        const response = await fetch("/api/lottery/results")
        const data = await response.json()

        if (response.ok && data.results) {
          const sortedWinners = data.results
            .map((winner: any) => ({
              ...winner,
              prizeAmount: Number.parseFloat(winner.prize.replace(/[^\d]/g, "")),
            }))
            .sort((a: Winner, b: Winner) => b.prizeAmount - a.prizeAmount)

          setWinners(sortedWinners)
        }
      } catch (error) {
        console.error("Kazananlar yüklenirken hata:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchWinners()
    const interval = setInterval(fetchWinners, 30000)
    return () => clearInterval(interval)
  }, [])

  const getRankIcon = (prizeAmount: number) => {
    if (prizeAmount >= 50000) return <Crown className="h-8 w-8 text-yellow-500" />
    if (prizeAmount >= 30000) return <Trophy className="h-7 w-7 text-yellow-600" />
    if (prizeAmount >= 15000) return <Medal className="h-6 w-6 text-gray-500" />
    if (prizeAmount >= 10000) return <Award className="h-6 w-6 text-orange-600" />
    if (prizeAmount >= 5000) return <Star className="h-5 w-5 text-purple-600" />
    return <Gift className="h-5 w-5 text-blue-600" />
  }

  const getRankBadgeColor = (prizeAmount: number) => {
    if (prizeAmount >= 50000) return "bg-gradient-to-r from-yellow-400 to-yellow-600 text-white"
    if (prizeAmount >= 30000) return "bg-gradient-to-r from-yellow-500 to-orange-500 text-white"
    if (prizeAmount >= 15000) return "bg-gradient-to-r from-gray-400 to-gray-600 text-white"
    if (prizeAmount >= 10000) return "bg-gradient-to-r from-orange-400 to-orange-600 text-white"
    if (prizeAmount >= 5000) return "bg-gradient-to-r from-purple-400 to-purple-600 text-white"
    return "bg-gradient-to-r from-blue-400 to-blue-600 text-white"
  }

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
        <p className="text-gray-500 mt-4">Kazananlar yükleniyor...</p>
      </div>
    )
  }

  if (winners.length === 0) {
    return null
  }

  const displayedWinners = showAll ? winners : winners.slice(0, 8)

  return (
    <section className="py-12">
      <div className="text-center mb-12">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-center gap-3 mb-4"
        >
          <Sparkles className="h-10 w-10 text-yellow-500 animate-pulse" />
          <h2 className="text-5xl font-bold bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent">
            🎉 KAZANANLAR AÇIKLANDI! 🎉
          </h2>
          <Sparkles className="h-10 w-10 text-yellow-500 animate-pulse" />
        </motion.div>
        <p className="text-xl text-orange-600 font-bold mb-4">ŞansCasino Büyük Çekiliş Sonuçları</p>
        <p className="text-lg text-gray-700 font-medium">
          Tebrikler kazanan arkadaşlarımız! Ödülleriniz için iletişime geçiniz.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
        <AnimatePresence>
          {displayedWinners.map((winner, index) => (
            <motion.div
              key={winner.id}
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -20 }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <Card className="backdrop-blur-md bg-white/90 border-2 border-yellow-200 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 hover:rotate-1">
                <CardHeader className="text-center pb-3">
                  <div className="flex items-center justify-center mb-2">{getRankIcon(winner.prizeAmount)}</div>
                  <CardTitle className="text-2xl font-bold text-gray-800 mb-2">{winner.prize}</CardTitle>
                  <Badge className={`${getRankBadgeColor(winner.prizeAmount)} font-bold text-sm px-3 py-1`}>
                    {winner.prizeAmount >= 50000
                      ? "🥇 BÜYÜK ÖDÜL"
                      : winner.prizeAmount >= 30000
                        ? "🥈 İKİNCİ ÖDÜL"
                        : winner.prizeAmount >= 15000
                          ? "🥉 ÜÇÜNCÜ ÖDÜL"
                          : winner.prizeAmount >= 10000
                            ? "🏆 DÖRDÜNCÜ ÖDÜL"
                            : winner.prizeAmount >= 5000
                              ? "⭐ BEŞİNCİ ÖDÜL"
                              : "🎁 TEŞEKKÜR ÖDÜLÜ"}
                  </Badge>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-3 rounded-lg border border-blue-200 mb-3">
                    <p className="text-sm text-gray-600 mb-1">Kazanan Bilet:</p>
                    <p className="text-xl font-mono font-bold text-blue-600">{winner.ticket_number}</p>
                  </div>
                  <p className="text-xs text-gray-500">{new Date(winner.created_at).toLocaleDateString("tr-TR")}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {winners.length > 8 && (
        <div className="text-center mb-8">
          <Button
            onClick={() => setShowAll(!showAll)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold px-8 py-3 rounded-lg shadow-lg"
          >
            {showAll ? "Daha Az Göster" : `Tüm Kazananları Göster (${winners.length})`}
          </Button>
        </div>
      )}

      {/* Gelecek Etkinlikler İçin Motivasyon Mesajı */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <Card className="bg-gradient-to-r from-blue-500 via-purple-600 to-pink-600 border-2 border-white/30 shadow-2xl">
          <CardContent className="p-8 text-center text-white">
            <div className="flex items-center justify-center gap-3 mb-6">
              <Bell className="h-8 w-8 text-yellow-300 animate-bounce" />
              <h3 className="text-3xl font-bold">Bir Sonraki Çekiliş İçin Hazır Olun!</h3>
              <Bell className="h-8 w-8 text-yellow-300 animate-bounce" />
            </div>

            <div className="space-y-4 text-lg">
              <p className="font-semibold">🎊 Bu çekilişte kazanamadınız mı? Üzülmeyin!</p>
              <p>
                ✨ <strong>Yeni etkinliklerimiz</strong> çok yakında başlayacak ve <strong>daha büyük ödüller</strong>{" "}
                sizi bekliyor!
              </p>
              <p>
                🚀 <strong>Takipte kalın</strong> ve bir sonraki çekilişte şansınızı deneyin!
              </p>
              <p className="text-yellow-200 font-bold text-xl">💎 Her yeni etkinlik, yeni bir şans demektir! 💎</p>
            </div>

            <div className="mt-8 space-y-4">
              <p className="text-sm opacity-90">
                📢 Yeni etkinliklerden haberdar olmak için sosyal medya hesaplarımızı takip edin!
              </p>
              <div className="flex items-center justify-center gap-4 text-sm">
                <span className="bg-white/20 px-4 py-2 rounded-full">📱 Telegram</span>
                <span className="bg-white/20 px-4 py-2 rounded-full">📘 Facebook</span>
                <span className="bg-white/20 px-4 py-2 rounded-full">📷 Instagram</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </section>
  )
}
