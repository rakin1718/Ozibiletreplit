"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/auth-context"
import { LogOut, LayoutDashboard, User } from "lucide-react"

interface AppHeaderProps {
  logoSrc: string
  logoAlt: string
  logoWidth: number
  logoHeight: number
  logoClassName?: string
}

export default function AppHeader({ logoSrc, logoAlt, logoWidth, logoHeight, logoClassName }: AppHeaderProps) {
  const { isLoggedIn, userRole, logout } = useAuth()

  return (
    <header className="backdrop-blur-md bg-gradient-to-r from-purple-500/20 via-pink-500/20 to-yellow-500/20 border-b border-white/30 sticky top-0 z-40">
      <div className="container mx-auto px-4 py-5">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {/* Logo sadece ana sayfaya yönlendirir, çıkış yapmaz */}
            <Link href="/" className="flex items-center">
              <Image
                src={logoSrc || "/placeholder.svg"}
                alt={logoAlt}
                width={logoWidth}
                height={logoHeight}
                className={logoClassName || "object-contain h-28"}
                priority
              />
            </Link>
          </div>
          <div className="flex gap-4">
            {isLoggedIn ? (
              <>
                {userRole === "admin" ? (
                  <Link href="/admin">
                    <Button
                      variant="outline"
                      className="backdrop-blur-sm bg-white/20 border-white/30 hover:bg-white/30"
                    >
                      <LayoutDashboard className="h-4 w-4 mr-2" /> Admin Paneli
                    </Button>
                  </Link>
                ) : (
                  <Link href="/dashboard">
                    <Button
                      variant="outline"
                      className="backdrop-blur-sm bg-white/20 border-white/30 hover:bg-white/30"
                    >
                      <User className="h-4 w-4 mr-2" /> Panelim
                    </Button>
                  </Link>
                )}
                <Button
                  onClick={logout}
                  variant="outline"
                  className="backdrop-blur-sm bg-white/20 border-white/30 hover:bg-white/30"
                >
                  <LogOut className="h-4 w-4 mr-2" /> Çıkış Yap
                </Button>
              </>
            ) : (
              <>
                <Link href="/auth/login">
                  <Button variant="default" className="bg-purple-600 hover:bg-purple-700 text-white">
                    Giriş Yap
                  </Button>
                </Link>
                <Link href="/auth/register">
                  <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Kayıt Ol
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
