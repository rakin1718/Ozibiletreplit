"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Trophy, Medal, Award, Gift, Loader2 } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface Winner {
  id: string
  userName: string
  ticketNumber: string
  prize: string
  eventName: string
  rank: number
}

export function WinnersSection() {
  const [winners, setWinners] = useState<Winner[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchLotteryResults = async () => {
      setLoading(true)
      setError(null)
      try {
        const response = await fetch("/api/lottery/results")
        const data = await response.json()

        if (!response.ok) {
          throw new Error(data.error || "Çekiliş sonuçları getirilemedi.")
        }

        const sortedWinners = data.results
          .map((winner: any) => ({
            id: winner.id,
            userName: winner.user_name,
            ticketNumber: winner.ticket_number,
            prize: winner.prize,
            eventName: winner.event_name,
            numericPrize: Number.parseFloat(winner.prize.replace(" TL", "").replace(",", "")),
          }))
          .sort((a: any, b: any) => b.numericPrize - a.numericPrize)
          .map((winner: any, index: number) => ({
            ...winner,
            rank: index + 1,
          }))

        setWinners(sortedWinners)
      } catch (err: any) {
        setError(err.message || "Çekiliş sonuçları yüklenirken bir hata oluştu.")
      } finally {
        setLoading(false)
      }
    }

    fetchLotteryResults()
    const interval = setInterval(fetchLotteryResults, 10000)
    return () => clearInterval(interval)
  }, [])

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-600" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-500" />
      case 3:
        return <Award className="h-6 w-6 text-orange-600" />
      default:
        return <Gift className="h-6 w-6 text-purple-600" />
    }
  }

  if (loading) {
    return (
      <div className="text-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600 mx-auto" />
        <p className="text-gray-500 mt-2">Kazananlar yükleniyor...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-600">
        <p>Kazananlar yüklenirken bir hata oluştu: {error}</p>
      </div>
    )
  }

  if (winners.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Henüz açıklanmış kazanan bulunmamaktadır.</p>
      </div>
    )
  }

  return (
    <section className="py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          SON ÇEKİLİŞ KAZANANLARI
        </h2>
        <p className="text-lg text-blue-700 font-medium">Şanslı isimler belli oldu!</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {winners.map((winner, index) => (
            <motion.div
              key={winner.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="backdrop-blur-md bg-white/80 border-green-200 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-lg font-bold text-gray-800">{winner.userName}</CardTitle>
                  <div className="flex items-center gap-2">
                    {getRankIcon(winner.rank)}
                    <span className="text-sm font-semibold text-gray-600">#{winner.rank}</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p className="text-2xl font-bold text-green-600">{winner.prize}</p>
                  <p className="text-sm text-gray-600">
                    Bilet Numarası: <span className="font-mono font-bold text-blue-600">{winner.ticketNumber}</span>
                  </p>
                  <p className="text-xs text-gray-500">Etkinlik: {winner.eventName}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </section>
  )
}
