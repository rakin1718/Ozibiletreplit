"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, Trophy, Sparkles, Heart, Target, Crown } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useAuth } from "@/context/auth-context"

interface UserLotteryStatus {
  isWinner: boolean
  prize?: string
  ticketNumber?: string
  message: string
}

export function UserLotteryStatusBanner() {
  const { isLoggedIn, user } = useAuth()
  const [lotteryStatus, setLotteryStatus] = useState<UserLotteryStatus | null>(null)
  const [showBanner, setShowBanner] = useState(false)

  // Güncellenmiş kazanan bilet numaraları
  const winningTickets = {
    "89024968": "50.000 TL",
    "79707490": "30.000 TL",
    "93090064": "15.000 TL",
    "27717995": "10.000 TL",
    "33192366": "5.000 TL",
    "56162266": "2.000 TL",
    "32549388": "2.000 TL",
    "73141479": "2.000 TL",
    "49209426": "2.000 TL",
    "72967992": "2.000 TL",
    "86291486": "2.000 TL",
    "27452358": "2.000 TL",
    "97181015": "2.000 TL",
    "78399609": "2.000 TL",
    "72848225": "2.000 TL",
  }

  useEffect(() => {
    if (!isLoggedIn || !user) return

    const checkUserLotteryStatus = async () => {
      try {
        // Kullanıcının yatırımlarını ve biletlerini kontrol et
        const response = await fetch(`/api/investments/user?userId=${user.id}`)
        const data = await response.json()

        if (response.ok && data.investments) {
          let userWon = false
          let winningTicket = ""
          let prize = ""

          // Kullanıcının tüm biletlerini kontrol et
          for (const investment of data.investments) {
            if (investment.status === "Onaylandı" && investment.tickets) {
              for (const ticket of investment.tickets) {
                if (winningTickets[ticket as keyof typeof winningTickets]) {
                  userWon = true
                  winningTicket = ticket
                  prize = winningTickets[ticket as keyof typeof winningTickets]
                  break
                }
              }
              if (userWon) break
            }
          }

          if (userWon) {
            setLotteryStatus({
              isWinner: true,
              prize: prize,
              ticketNumber: winningTicket,
              message: `🎉 TEBRİKLER! ${prize} KAZANDINIZ! 🎉`,
            })
          } else {
            // Kullanıcının onaylanmış yatırımı var mı kontrol et
            const hasApprovedInvestment = data.investments.some((inv: any) => inv.status === "Onaylandı")

            if (hasApprovedInvestment) {
              setLotteryStatus({
                isWinner: false,
                message:
                  "Bu sefer kazanamadınız ama üzülmeyin! Yeni etkinliklerimiz çok yakında başlayacak. Takipte kalın! 💪",
              })
            }
          }

          if (userWon || data.investments.some((inv: any) => inv.status === "Onaylandı")) {
            setShowBanner(true)
          }
        }
      } catch (error) {
        console.error("Çekiliş durumu kontrol edilemedi:", error)
      }
    }

    checkUserLotteryStatus()
  }, [isLoggedIn, user])

  const closeBanner = () => {
    setShowBanner(false)
    setLotteryStatus(null)
  }

  if (!showBanner || !lotteryStatus) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="fixed top-20 right-4 z-50 max-w-sm"
      >
        <Card
          className={`${
            lotteryStatus.isWinner
              ? "bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500"
              : "bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500"
          } border-white/30 shadow-2xl`}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                {lotteryStatus.isWinner ? (
                  <Crown className="h-6 w-6 text-white animate-bounce" />
                ) : (
                  <Heart className="h-6 w-6 text-white animate-pulse" />
                )}
                <h3 className="text-lg font-bold text-white">
                  {lotteryStatus.isWinner ? "KAZANDINIZ!" : "Bir Dahaki Sefere!"}
                </h3>
              </div>
              <Button onClick={closeBanner} variant="ghost" size="sm" className="text-white hover:bg-white/20">
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="text-center">
              {lotteryStatus.isWinner ? (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2 }}
                  className="bg-white/90 rounded-lg p-4 mb-4"
                >
                  <div className="flex items-center justify-center mb-2">
                    <Trophy className="h-8 w-8 text-yellow-600 mr-2" />
                    <div className="text-2xl font-bold text-gray-800">{lotteryStatus.prize}</div>
                  </div>
                  <div className="text-sm text-gray-600 mb-1">
                    Kazanan Bilet: <span className="font-mono font-bold">{lotteryStatus.ticketNumber}</span>
                  </div>
                  <div className="text-xs text-gray-500">ŞansCasino Büyük Çekiliş</div>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2 }}
                  className="bg-white/90 rounded-lg p-4 mb-4"
                >
                  <div className="flex items-center justify-center mb-2">
                    <Target className="h-8 w-8 text-purple-600 mr-2" />
                    <div className="text-lg font-bold text-gray-800">Yeni Etkinlikler Geliyor!</div>
                  </div>
                  <div className="text-sm text-gray-600">Daha büyük ödüller için hazır olun! 🎯</div>
                </motion.div>
              )}

              <p className="text-white text-sm mb-4">{lotteryStatus.message}</p>

              {!lotteryStatus.isWinner && (
                <div className="flex items-center justify-center gap-2 text-white/80 text-xs">
                  <Sparkles className="h-4 w-4" />
                  <span>Yeni etkinliklere katılmaya devam edin!</span>
                  <Sparkles className="h-4 w-4" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}
