"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, Ticket, Shield, CheckCircle, Eye } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function WelcomeInfoBanner() {
  const [showBanner, setShowBanner] = useState(false)

  useEffect(() => {
    // Daha önce banner görülmüş mü kontrol et
    const hasSeenWelcomeBanner = localStorage.getItem("hasSeenWelcomeBanner")
    if (!hasSeenWelcomeBanner) {
      setShowBanner(true)
    }
  }, [])

  const closeBanner = () => {
    setShowBanner(false)
    // Banner kapatıldığında localStorage'a kaydet
    localStorage.setItem("hasSeenWelcomeBanner", "true")
  }

  if (!showBanner) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={closeBanner}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          className="relative max-w-2xl w-full"
          onClick={(e) => e.stopPropagation()}
        >
          <Card className="bg-gradient-to-br from-white via-blue-50 to-purple-50 border-2 border-blue-300 shadow-2xl">
            {/* Kapatma Butonu */}
            <Button
              onClick={closeBanner}
              variant="ghost"
              size="sm"
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full z-10"
            >
              <X className="h-5 w-5" />
            </Button>

            <CardContent className="p-6 md:p-8">
              {/* Başlık */}
              <div className="text-center mb-6">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Ticket className="h-8 w-8 text-blue-600 animate-bounce" />
                  <h2 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    🎟️ Hoş Geldiniz!
                  </h2>
                </div>
                <p className="text-lg md:text-xl font-semibold text-gray-800 mb-2">
                  Kendi Biletinizi Almak Artık Çok Kolay!
                </p>
                <p className="text-blue-600 font-medium">ozibilet.com sistemine hoş geldiniz!</p>
              </div>

              {/* Ana Metin */}
              <div className="mb-6">
                <p className="text-gray-700 mb-4 text-center">
                  Bilet alma işleminizi başlatmak için lütfen aşağıdaki adımları takip edin:
                </p>

                {/* Adımlar */}
                <div className="space-y-4">
                  {/* Adım 1 */}
                  <div className="flex items-start gap-3 p-4 bg-white/80 rounded-lg border border-blue-200 shadow-sm">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Shield className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 mb-1">🔐 Hesap Oluşturun</h3>
                      <p className="text-sm text-gray-600">Kullanıcı adı ve şifrenizle kolayca üyelik oluşturun.</p>
                    </div>
                  </div>

                  {/* Adım 2 */}
                  <div className="flex items-start gap-3 p-4 bg-white/80 rounded-lg border border-green-200 shadow-sm">
                    <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-green-600 font-bold text-sm">💸</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 mb-1">💸 Yatırımınızı Belirtin</h3>
                      <p className="text-sm text-gray-600">
                        Hesabınıza giriş yaptıktan sonra yatırım miktarınızı ve kullanıcı adınızı eksiksiz girin.
                      </p>
                    </div>
                  </div>

                  {/* Adım 3 */}
                  <div className="flex items-start gap-3 p-4 bg-white/80 rounded-lg border border-yellow-200 shadow-sm">
                    <div className="flex-shrink-0 w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="h-4 w-4 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 mb-1">✅ Kontrol ve Onay Süreci</h3>
                      <p className="text-sm text-gray-600">
                        Ekiplerimiz tarafından yatırım bilgileriniz kontrol edilir. Onay sonrası size özel bilet
                        numaranız sistem tarafından otomatik atanır.
                      </p>
                    </div>
                  </div>

                  {/* Adım 4 */}
                  <div className="flex items-start gap-3 p-4 bg-white/80 rounded-lg border border-purple-200 shadow-sm">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                      <Eye className="h-4 w-4 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 mb-1">🎫 Bilet Numaranızı Görüntüleyin</h3>
                      <p className="text-sm text-gray-600">
                        Bilet numaranızı, profilinizden "Biletlerim" bölümünden kolayca takip edebilirsiniz.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Alt Buton */}
              <div className="text-center">
                <Button
                  onClick={closeBanner}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold px-8 py-2 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Anladım, Başlayalım! 🚀
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
