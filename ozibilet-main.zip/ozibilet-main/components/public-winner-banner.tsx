"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, Trophy, Sparkles, Gift, Star, Crown } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface Winner {
  id: string
  userName: string
  ticketNumber: string
  prize: string
  eventName: string
}

export function PublicWinnerBanner() {
  const [winners, setWinners] = useState<Winner[]>([])
  const [showBanner, setShowBanner] = useState(false)

  useEffect(() => {
    // Çekiliş sonuçlarını kontrol et
    const checkWinners = () => {
      const storedWinners = localStorage.getItem("lottery_winners")
      if (storedWinners) {
        const winnersData = JSON.parse(storedWinners)
        setWinners(winnersData)
        setShowBanner(true)
      }
    }

    checkWinners()
    // Her 10 saniyede bir kontrol et
    const interval = setInterval(checkWinners, 10000)
    return () => clearInterval(interval)
  }, [])

  const closeBanner = () => {
    setShowBanner(false)
  }

  if (!showBanner || winners.length === 0) return null

  // İlk 6 kazananı göster
  const displayWinners = winners.slice(0, 6)

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -100 }}
        className="fixed top-0 left-0 right-0 z-50 p-4"
      >
        <Card className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 border-yellow-300 shadow-2xl">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Crown className="h-8 w-8 text-white animate-bounce" />
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  🎉 ÇEKİLİŞ SONUÇLARI AÇIKLANDI! 🎉
                  <Sparkles className="h-6 w-6 text-yellow-200 animate-pulse" />
                </h2>
              </div>
              <Button onClick={closeBanner} variant="ghost" size="sm" className="text-white hover:bg-white/20">
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
              {displayWinners.map((winner, index) => (
                <motion.div
                  key={winner.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white/95 backdrop-blur-sm rounded-lg p-4 border border-yellow-200"
                >
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-2">
                      {index === 0 && <Trophy className="h-6 w-6 text-yellow-600 mr-1" />}
                      {index === 1 && <Star className="h-6 w-6 text-gray-500 mr-1" />}
                      {index === 2 && <Gift className="h-6 w-6 text-orange-600 mr-1" />}
                      <div className="text-lg font-bold text-gray-800">{winner.prize}</div>
                    </div>
                    <div className="text-blue-600 font-semibold mb-1">{winner.userName}</div>
                    <div className="text-sm text-gray-600 mb-1">
                      Bilet: <span className="font-mono font-bold">{winner.ticketNumber}</span>
                    </div>
                    <div className="text-xs text-gray-500">{winner.eventName}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="text-center">
              <p className="text-white text-sm mb-2">
                🎊 Tebrikler kazanan arkadaşlarımız! Ödülleriniz için iletişime geçiniz. 🎊
              </p>
              {winners.length > 6 && (
                <p className="text-white/80 text-xs">
                  +{winners.length - 6} kişi daha kazandı! Tüm sonuçlar aşağıda listelenmiştir.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  )
}
