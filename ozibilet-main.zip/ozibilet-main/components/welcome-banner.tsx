"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Lightbulb, Info } from "lucide-react"

export function WelcomeBanner() {
  return (
    <div className="relative mb-4 mx-auto max-w-xl px-4">
      <Card className="bg-gradient-to-r from-blue-500 to-purple-600 border-2 border-blue-300 shadow-lg rounded-lg text-white">
        <CardContent className="p-3 md:p-4">
          <div className="flex items-center gap-3">
            <div className="flex-shrink-0">
              <Lightbulb className="h-6 w-6 md:h-8 md:w-8 text-yellow-300 animate-pulse" />
            </div>
            <div className="flex-grow">
              <h1 className="text-sm md:text-lg font-bold mb-1">Ozi Bilet Platformuna Hoş Geldiniz!</h1>
              <p className="text-xs md:text-sm mb-2 opacity-90">
                Şansınızı denemek ve büyük ödüller kazanmak için doğru yerdesiniz!
              </p>

              <div className="space-y-1 text-xs text-blue-100">
                <div className="flex items-start gap-1">
                  <Info className="h-2 w-2 flex-shrink-0 mt-1" />
                  <p>1. Etkinlikleri keşfedin ve yatırım yapın</p>
                </div>
                <div className="flex items-start gap-1">
                  <Info className="h-2 w-2 flex-shrink-0 mt-1" />
                  <p>2. Her 1000 TL yatırım bir bilet kazandırır</p>
                </div>
                <div className="flex items-start gap-1">
                  <Info className="h-2 w-2 flex-shrink-0 mt-1" />
                  <p>3. Çekiliş sonuçlarını takip edin</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
