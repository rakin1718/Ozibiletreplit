"use client"

import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trophy, Bell } from "lucide-react"
import Image from "next/image"
import { WelcomeBanner } from "@/components/welcome-banner"
import { WinnerBanner } from "@/components/winner-banner"
import { BigWinnersShowcase } from "@/components/big-winners-showcase"
import AppHeader from "@/components/app-header"

export default function HomePage() {
  const handleTakipteKal = () => {
    window.open("https://t.me/ozibey2", "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100">
      <AppHeader
        logoSrc="/images/ozi-bilet-logo.png"
        logoAlt="Ozi Bilet Logo"
        logoWidth={350}
        logoHeight={140}
        logoClassName="object-contain h-28"
      />

      {/* Kazanan Banner - Çekiliş yapıldığında gösterilir */}
      <WinnerBanner />

      {/* Karşılama Banner - Küçültülmüş */}
      <WelcomeBanner />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto space-y-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent mb-4">
              AKTİF ETKİNLİKLER
            </h1>
            <p className="text-lg text-purple-700 font-medium">BÜYÜK ÖDÜLLÜ ETKİNLİKLERE KATIL</p>
          </div>

          {/* Prize Banner */}
          <div className="text-center mb-8">
            <div className="max-w-4xl mx-auto">
              <Image
                src="/images/prize-banner.jpeg"
                alt="Büyük Ödüller - Bilet Etkinliği"
                width={800}
                height={600}
                className="w-full h-auto rounded-2xl shadow-2xl border-4 border-yellow-300"
                priority
              />
            </div>
          </div>

          {/* Şanscasino Etkinliği, Kazananlar ve Yeni Etkinlikler */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {/* ŞansCasino Etkinlik Kartı */}
            <Card className="backdrop-blur-md shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105 bg-gradient-to-br from-white/60 via-purple-50/80 to-pink-50/80 border-purple-200/50">
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4">
                  <Image
                    src="/images/sanscasino-new-logo.png"
                    alt="ŞansCasino Logo"
                    width={144}
                    height={96}
                    className="object-contain w-full h-full"
                  />
                </div>
                <CardTitle className="text-xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent mb-2">
                  ŞansCasino Etkinliği
                </CardTitle>
                <CardDescription className="text-sm font-semibold text-red-600">⏰ ETKİNLİK BİTTİ</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <p className="text-gray-700 text-sm mb-1">150.000 TL Ödül Havuzu</p>
                  <p className="text-xs text-gray-600 mb-3">Çekiliş Tamamlandı</p>
                </div>

                <div className="space-y-2">
                  <Button
                    size="sm"
                    disabled
                    className="w-full bg-gray-400 text-white font-bold py-2 px-4 rounded-lg text-sm mb-2 cursor-not-allowed"
                  >
                    Etkinlik Sona Erdi
                  </Button>

                  <Link href="/event/sanscasino">
                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full border-2 border-gray-400 text-gray-600 hover:bg-gray-100 font-bold py-2 px-4 rounded-lg text-sm bg-transparent"
                    >
                      Detayları Gör
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Kazananlar Kartı */}
            <Card className="backdrop-blur-md shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105 bg-gradient-to-br from-yellow-50/80 via-orange-50/80 to-red-50/80 border-yellow-200/50">
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4">
                  <div className="w-24 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                    <Trophy className="h-10 w-10 text-white" />
                  </div>
                </div>
                <CardTitle className="text-xl font-bold bg-gradient-to-r from-yellow-600 via-orange-600 to-red-600 bg-clip-text text-transparent mb-2">
                  Büyük Kazananlar
                </CardTitle>
                <CardDescription className="text-sm font-semibold text-orange-700">
                  🏆 ŞansCasino Çekiliş Sonuçları
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <p className="text-gray-700 text-sm mb-1">Şeffaflık İçin Paylaşıyoruz</p>
                  <p className="text-xs text-gray-600 mb-3">Büyük Ödül Kazananları</p>
                </div>

                <div className="space-y-2">
                  <Button
                    size="sm"
                    className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white font-bold py-2 px-4 rounded-lg shadow-lg transition-all duration-300 text-sm"
                    onClick={() => {
                      const winnersSection = document.getElementById("big-winners-section")
                      if (winnersSection) {
                        winnersSection.scrollIntoView({ behavior: "smooth", block: "start" })
                      }
                    }}
                  >
                    🏆 Kazananları Gör
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Yeni Etkinlikler Kartı */}
            <Card className="backdrop-blur-md shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105 bg-gradient-to-br from-blue-50/80 via-indigo-50/80 to-purple-50/80 border-blue-200/50">
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4">
                  <div className="w-24 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <Bell className="h-10 w-10 text-white animate-pulse" />
                  </div>
                </div>
                <CardTitle className="text-xl font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent mb-2">
                  Yeni Etkinlikler
                </CardTitle>
                <CardDescription className="text-sm font-semibold text-blue-700">🚀 Yakında Başlayacak</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <p className="text-gray-700 text-sm mb-1">Daha Büyük Ödüller Geliyor</p>
                  <p className="text-xs text-gray-600 mb-3">Hazırlıklar Devam Ediyor</p>
                </div>

                <div className="space-y-2">
                  <Button
                    size="sm"
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-2 px-4 rounded-lg shadow-lg transition-all duration-300 text-sm"
                    onClick={handleTakipteKal}
                  >
                    🔔 Takipte Kal
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Büyük Kazananlar Bölümü - Herkese Açık */}
          <div id="big-winners-section">
            <BigWinnersShowcase />
          </div>
        </div>
      </main>
    </div>
  )
}
