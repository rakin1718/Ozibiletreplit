"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/context/auth-context"
import AppHeader from "@/components/app-header"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  CheckCircle,
  XCircle,
  Loader2,
  Trophy,
  Users,
  TrendingUp,
  Ticket,
  Crown,
  Medal,
  Award,
  Star,
  Gift,
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

interface Investment {
  id: string
  user_id: string
  user_email: string
  user_name: string
  amount: number
  sans_username: string
  status: "Bekliyor" | "Onaylandı" | "Reddedildi"
  company: string
  created_at: string
  tickets?: string[] | null
  investment_count?: number // Yeni alan
}

interface User {
  id: string
  full_name: string
  email: string
  phone: string
  created_at: string
}

interface LotteryResult {
  id: string
  user_name: string
  ticket_number: string
  prize: string
  event_name: string
  created_at: string
}

export default function AdminPage() {
  const { isLoggedIn, userRole } = useAuth()
  const router = useRouter()
  const [investments, setInvestments] = useState<Investment[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [lotteryResults, setLotteryResults] = useState<LotteryResult[]>([])
  const [filteredLotteryResults, setFilteredLotteryResults] = useState<LotteryResult[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lotteryMessage, setLotteryMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [selectedCompany, setSelectedCompany] = useState("")
  const [selectedCompanyForInvestments, setSelectedCompanyForInvestments] = useState("")
  const [selectedCompanyForHistory, setSelectedCompanyForHistory] = useState("")

  const companies = [{ id: "sanscasino", name: "ŞansCasino" }]

  useEffect(() => {
    if (!isLoggedIn || userRole !== "admin") {
      router.push("/auth/login")
      return
    }

    fetchData()
    const interval = setInterval(fetchData, 10000)
    return () => clearInterval(interval)
  }, [isLoggedIn, userRole, router, selectedCompanyForInvestments])

  useEffect(() => {
    // Etkinlik geçmişi için filtreleme
    if (selectedCompanyForHistory) {
      const filtered = lotteryResults.filter((result) => {
        const eventName = result.event_name.toLowerCase()
        const selectedCompany = selectedCompanyForHistory.toLowerCase()

        // Hem "ŞansCasino" hem de "ŞansCasino Büyük Çekiliş" için çalışsın
        return (
          eventName.includes(selectedCompany) || eventName.includes("şanscasino") || eventName.includes("sanscasino")
        )
      })
      setFilteredLotteryResults(filtered)
    } else {
      setFilteredLotteryResults([])
    }
  }, [selectedCompanyForHistory, lotteryResults])

  const fetchData = async () => {
    try {
      // Yatırımları getir - sadece firma seçilmişse
      if (selectedCompanyForInvestments) {
        const investmentsResponse = await fetch(`/api/investments?company=${selectedCompanyForInvestments}`)
        const investmentsData = await investmentsResponse.json()
        if (investmentsResponse.ok) {
          setInvestments(investmentsData.investments)
        }
      } else {
        setInvestments([]) // Firma seçilmemişse boş array
      }

      // Kullanıcıları getir
      const usersResponse = await fetch("/api/users")
      const usersData = await usersResponse.json()
      if (usersResponse.ok) {
        setUsers(usersData)
      }

      // Çekiliş sonuçlarını getir
      const lotteryResponse = await fetch("/api/lottery/results")
      const lotteryData = await lotteryResponse.json()
      if (lotteryResponse.ok) {
        setLotteryResults(lotteryData.results)
      }
    } catch (err: any) {
      setError("Veriler yüklenirken bir hata oluştu.")
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (id: string, newStatus: "Onaylandı" | "Reddedildi") => {
    try {
      const response = await fetch(`/api/investments`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: newStatus }),
      })
      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || "Durum güncellenemedi.")
      }
      fetchData()
    } catch (err: any) {
      setError(err.message || "Durum güncellenirken bir hata oluştu.")
    }
  }

  const handleConductLottery = async () => {
    setLotteryMessage(null)
    if (!selectedCompany) {
      setLotteryMessage({ type: "error", text: "Lütfen şirketi seçin." })
      return
    }

    try {
      const response = await fetch("/api/lottery/conduct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          company: selectedCompany,
        }),
      })
      const data = await response.json()

      if (response.ok) {
        setLotteryMessage({ type: "success", text: data.message || "Çekiliş başarıyla yapıldı!" })
        setSelectedCompany("")

        // Kazanan bannerını göstermek için localStorage'a kaydet
        localStorage.setItem("lottery_winners", JSON.stringify(data.winners))
        localStorage.setItem("show_winner_banner", "true")

        fetchData()
      } else {
        setLotteryMessage({ type: "error", text: data.error || "Çekiliş yapılırken bir hata oluştu." })
      }
    } catch (err: any) {
      setLotteryMessage({ type: "error", text: "Bir hata oluştu. Lütfen daha sonra tekrar deneyin." })
    }
  }

  const handleBackfillTickets = async () => {
    setLotteryMessage(null) // Önceki mesajları temizle
    try {
      const response = await fetch("/api/investments/backfill-tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      })
      const data = await response.json()

      if (response.ok) {
        setLotteryMessage({ type: "success", text: data.message })
        fetchData() // Verileri yenile
      } else {
        setLotteryMessage({ type: "error", text: data.error || "Bilet atama işlemi başarısız oldu." })
      }
    } catch (err: any) {
      setLotteryMessage({ type: "error", text: "Bilet atama sırasında bir hata oluştu." })
      console.error("Backfill tickets error:", err)
    }
  }

  const getPrizeIcon = (prize: string) => {
    const prizeAmount = Number.parseInt(prize.replace(/[^\d]/g, ""))
    if (prizeAmount >= 50000) return <Crown className="h-6 w-6 text-yellow-500" />
    if (prizeAmount >= 30000) return <Trophy className="h-6 w-6 text-yellow-600" />
    if (prizeAmount >= 15000) return <Medal className="h-6 w-6 text-gray-500" />
    if (prizeAmount >= 10000) return <Award className="h-6 w-6 text-orange-600" />
    if (prizeAmount >= 5000) return <Star className="h-6 w-6 text-purple-600" />
    return <Gift className="h-6 w-6 text-blue-600" />
  }

  const getPrizeBadgeColor = (prize: string) => {
    const prizeAmount = Number.parseInt(prize.replace(/[^\d]/g, ""))
    if (prizeAmount >= 50000) return "bg-gradient-to-r from-yellow-400 to-yellow-600 text-white"
    if (prizeAmount >= 30000) return "bg-gradient-to-r from-yellow-500 to-orange-500 text-white"
    if (prizeAmount >= 15000) return "bg-gradient-to-r from-gray-400 to-gray-600 text-white"
    if (prizeAmount >= 10000) return "bg-gradient-to-r from-orange-400 to-orange-600 text-white"
    if (prizeAmount >= 5000) return "bg-gradient-to-r from-purple-400 to-purple-600 text-white"
    return "bg-gradient-to-r from-blue-400 to-blue-600 text-white"
  }

  if (!isLoggedIn || userRole !== "admin") {
    return null
  }

  const totalUsers = users.length
  const totalInvestments = investments.reduce((sum, inv) => sum + inv.amount, 0)
  const pendingInvestments = investments.filter((inv) => inv.status === "Bekliyor").length
  const completedLotteries = lotteryResults.length

  // Çekiliş sonuçlarını ödül miktarına göre sırala
  const sortedLotteryResults = filteredLotteryResults.sort((a, b) => {
    const prizeA = Number.parseInt(a.prize.replace(/[^\d]/g, ""))
    const prizeB = Number.parseInt(b.prize.replace(/[^\d]/g, ""))
    return prizeB - prizeA
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100">
      <AppHeader
        logoSrc="/images/ozi-bilet-logo.png"
        logoAlt="Ozi Bilet Logo"
        logoWidth={250}
        logoHeight={100}
        logoClassName="object-contain h-16 md:h-28"
      />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900">Yönetici Paneli</h1>
            <p className="text-gray-700 font-medium">Tüm etkinlikler yönetim paneli</p>
          </div>

          {error && (
            <Alert variant="destructive" className="bg-red-50 border-2 border-red-300">
              <XCircle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-800 font-bold">Hata!</AlertTitle>
              <AlertDescription className="text-red-700">{error}</AlertDescription>
            </Alert>
          )}

          {/* İstatistikler */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-white border-2 border-gray-200 shadow-lg">
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                <div className="text-2xl font-bold text-gray-900">{totalUsers}</div>
                <div className="text-sm text-gray-700 font-medium">Toplam Kullanıcı</div>
              </CardContent>
            </Card>
            <Card className="bg-white border-2 border-gray-200 shadow-lg">
              <CardContent className="p-4 text-center">
                <TrendingUp className="h-8 w-8 mx-auto mb-2 text-green-600" />
                <div className="text-2xl font-bold text-gray-900">{totalInvestments.toLocaleString("tr-TR")} TL</div>
                <div className="text-sm text-gray-700 font-medium">Toplam Yatırım</div>
              </CardContent>
            </Card>
            <Card className="bg-white border-2 border-gray-200 shadow-lg">
              <CardContent className="p-4 text-center">
                <Loader2 className="h-8 w-8 mx-auto mb-2 text-yellow-600" />
                <div className="text-2xl font-bold text-gray-900">{pendingInvestments}</div>
                <div className="text-sm text-gray-700 font-medium">Bekleyen Yatırım</div>
              </CardContent>
            </Card>
            <Card className="bg-white border-2 border-gray-200 shadow-lg">
              <CardContent className="p-4 text-center">
                <Trophy className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                <div className="text-2xl font-bold text-gray-900">{completedLotteries}</div>
                <div className="text-sm text-gray-700 font-medium">Tamamlanan Çekiliş</div>
              </CardContent>
            </Card>
          </div>

          {/* Sekmeli İçerik */}
          <Tabs defaultValue="investments" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-white border-2 border-gray-200">
              <TabsTrigger
                value="investments"
                className="text-gray-900 font-semibold data-[state=active]:bg-purple-100 data-[state=active]:text-purple-800"
              >
                Yatırım Yönetimi
              </TabsTrigger>
              <TabsTrigger
                value="users"
                className="text-gray-900 font-semibold data-[state=active]:bg-purple-100 data-[state=active]:text-purple-800"
              >
                Kullanıcı Listesi
              </TabsTrigger>
              <TabsTrigger
                value="lottery"
                className="text-gray-900 font-semibold data-[state=active]:bg-purple-100 data-[state=active]:text-purple-800"
              >
                Çekiliş Yönetimi
              </TabsTrigger>
              <TabsTrigger
                value="history"
                className="text-gray-900 font-semibold data-[state=active]:bg-purple-100 data-[state=active]:text-purple-800"
              >
                Etkinlik Geçmişi
              </TabsTrigger>
            </TabsList>

            {/* Yatırım Yönetimi */}
            <TabsContent value="investments">
              <Card className="bg-white border-2 border-gray-200 shadow-lg">
                <CardHeader className="bg-gray-50 border-b-2 border-gray-200">
                  <CardTitle className="text-gray-900 font-bold text-xl">Yatırım Yönetimi</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  {/* Firma Seçimi */}
                  <div className="mb-6">
                    <label className="block text-gray-900 font-bold mb-2">Firma Seçin</label>
                    <Select value={selectedCompanyForInvestments} onValueChange={setSelectedCompanyForInvestments}>
                      <SelectTrigger className="bg-gray-50 border-2 border-gray-300 text-gray-900 max-w-md">
                        <SelectValue placeholder="Yatırımlarını görmek istediğiniz firmayı seçin" />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-2 border-gray-300">
                        {companies.map((company) => (
                          <SelectItem key={company.id} value={company.name} className="text-gray-900 hover:bg-gray-100">
                            {company.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {!selectedCompanyForInvestments ? (
                    <div className="text-center py-12">
                      <div className="text-gray-500 text-lg">
                        👆 Yatırımları görüntülemek için yukarıdan bir firma seçin
                      </div>
                    </div>
                  ) : loading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
                    </div>
                  ) : (
                    <div>
                      <div className="mb-4">
                        <h3 className="text-lg font-bold text-gray-900">{selectedCompanyForInvestments} Yatırımları</h3>
                        <p className="text-gray-600">Toplam {investments.length} yatırım</p>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-100">
                              <TableHead className="text-gray-900 font-bold">Kullanıcı</TableHead>
                              <TableHead className="text-gray-900 font-bold">Firma</TableHead>
                              <TableHead className="text-gray-900 font-bold">ŞansCasino ID</TableHead>
                              <TableHead className="text-gray-900 font-bold">Toplam Tutar</TableHead>
                              <TableHead className="text-gray-900 font-bold">Yatırım Sayısı</TableHead>
                              <TableHead className="text-gray-900 font-bold">Son Tarih</TableHead>
                              <TableHead className="text-gray-900 font-bold">Durum</TableHead>
                              <TableHead className="text-gray-900 font-bold">Toplam Biletler</TableHead>
                              <TableHead className="text-gray-900 font-bold">İşlemler</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {investments.map((investment) => (
                              <TableRow key={investment.id} className="hover:bg-gray-50">
                                <TableCell className="text-gray-900 font-medium">{investment.user_name}</TableCell>
                                <TableCell className="text-gray-900">{investment.company}</TableCell>
                                <TableCell className="text-gray-900 text-sm">{investment.sans_username}</TableCell>
                                <TableCell className="text-gray-900 font-semibold">
                                  {investment.amount.toLocaleString("tr-TR")} TL
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                    {investment.investment_count || 1} adet
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-gray-700">
                                  {new Date(investment.created_at).toLocaleDateString("tr-TR")}
                                </TableCell>
                                <TableCell>
                                  <span
                                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                                      investment.status === "Onaylandı"
                                        ? "bg-green-100 text-green-800 border border-green-300"
                                        : investment.status === "Bekliyor"
                                          ? "bg-yellow-100 text-yellow-800 border border-yellow-300"
                                          : "bg-red-100 text-red-800 border border-red-300"
                                    }`}
                                  >
                                    {investment.status}
                                  </span>
                                </TableCell>
                                <TableCell className="text-gray-900">
                                  {investment.status === "Onaylandı" &&
                                  investment.tickets &&
                                  Array.isArray(investment.tickets) &&
                                  investment.tickets.length > 0 ? (
                                    <div className="flex flex-col items-start">
                                      <div className="flex items-center gap-2 mb-1">
                                        <Badge className="bg-green-100 text-green-800 border-green-200">
                                          {investment.tickets.length} bilet
                                        </Badge>
                                      </div>
                                      <span className="font-mono text-blue-600 font-bold text-sm">
                                        {investment.tickets.slice(0, 3).join(", ")}
                                        {investment.tickets.length > 3 && "..."}
                                      </span>
                                      {investment.tickets.length > 3 && (
                                        <Dialog>
                                          <DialogTrigger asChild>
                                            <Button
                                              variant="link"
                                              size="sm"
                                              className="p-0 h-auto text-xs text-purple-600 hover:underline"
                                            >
                                              Tümünü Gör ({investment.tickets.length})
                                            </Button>
                                          </DialogTrigger>
                                          <DialogContent className="sm:max-w-[425px] md:max-w-lg lg:max-w-xl">
                                            <DialogHeader>
                                              <DialogTitle>Tüm Bilet Numaraları - {investment.user_name}</DialogTitle>
                                            </DialogHeader>
                                            <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                                              {investment.tickets.map((ticket, idx) => (
                                                <Badge
                                                  key={idx}
                                                  variant="secondary"
                                                  className="text-center text-sm font-mono"
                                                >
                                                  {ticket}
                                                </Badge>
                                              ))}
                                            </div>
                                          </DialogContent>
                                        </Dialog>
                                      )}
                                    </div>
                                  ) : investment.status === "Bekliyor" ? (
                                    <span className="text-gray-500">Onay bekliyor</span>
                                  ) : (
                                    <span className="text-gray-500">Bilet yok</span>
                                  )}
                                </TableCell>
                                <TableCell>
                                  {investment.status === "Bekliyor" && (
                                    <div className="flex gap-2">
                                      <Button
                                        size="sm"
                                        className="bg-green-600 hover:bg-green-700 text-white font-bold"
                                        onClick={() => handleStatusChange(investment.id, "Onaylandı")}
                                      >
                                        Onayla
                                      </Button>
                                      <Button
                                        size="sm"
                                        className="bg-red-600 hover:bg-red-700 text-white font-bold"
                                        onClick={() => handleStatusChange(investment.id, "Reddedildi")}
                                      >
                                        Reddet
                                      </Button>
                                    </div>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Kullanıcı Listesi */}
            <TabsContent value="users">
              <Card className="bg-white border-2 border-gray-200 shadow-lg">
                <CardHeader className="bg-gray-50 border-b-2 border-gray-200">
                  <CardTitle className="text-gray-900 font-bold text-xl">Kullanıcı Listesi</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-100">
                          <TableHead className="text-gray-900 font-bold">Ad Soyad</TableHead>
                          <TableHead className="text-gray-900 font-bold">E-posta</TableHead>
                          <TableHead className="text-gray-900 font-bold">Telefon</TableHead>
                          <TableHead className="text-gray-900 font-bold">Kayıt Tarihi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users.map((user) => (
                          <TableRow key={user.id} className="hover:bg-gray-50">
                            <TableCell className="text-gray-900 font-medium">{user.full_name}</TableCell>
                            <TableCell className="text-gray-900">{user.email}</TableCell>
                            <TableCell className="text-gray-900">{user.phone}</TableCell>
                            <TableCell className="text-gray-700">
                              {new Date(user.created_at).toLocaleDateString("tr-TR")}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Çekiliş Yönetimi */}
            <TabsContent value="lottery">
              <Card className="bg-white border-2 border-gray-200 shadow-lg">
                <CardHeader className="bg-gray-50 border-b-2 border-gray-200">
                  <CardTitle className="text-gray-900 font-bold text-xl">Çekiliş Yönetimi</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div className="max-w-md">
                    <label className="block text-gray-900 font-bold mb-2">Şirket Seç</label>
                    <Select value={selectedCompany} onValueChange={setSelectedCompany}>
                      <SelectTrigger className="bg-gray-50 border-2 border-gray-300 text-gray-900">
                        <SelectValue placeholder="Bir şirket seçin" />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-2 border-gray-300">
                        {companies.map((company) => (
                          <SelectItem key={company.id} value={company.name} className="text-gray-900 hover:bg-gray-100">
                            {company.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {lotteryMessage && (
                    <Alert
                      variant={lotteryMessage.type === "error" ? "destructive" : "default"}
                      className={
                        lotteryMessage.type === "success"
                          ? "bg-green-50 border-2 border-green-300"
                          : "bg-red-50 border-2 border-red-300"
                      }
                    >
                      {lotteryMessage.type === "success" ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-600" />
                      )}
                      <AlertTitle
                        className={
                          lotteryMessage.type === "success" ? "text-green-800 font-bold" : "text-red-800 font-bold"
                        }
                      >
                        {lotteryMessage.type === "success" ? "Başarılı!" : "Hata!"}
                      </AlertTitle>
                      <AlertDescription
                        className={lotteryMessage.type === "success" ? "text-green-700" : "text-red-700"}
                      >
                        {lotteryMessage.text}
                      </AlertDescription>
                    </Alert>
                  )}
                  <Button
                    onClick={handleConductLottery}
                    className="w-full bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white font-bold py-3 text-lg"
                  >
                    <Trophy className="h-5 w-5 mr-2" /> Çekilişi Yap
                  </Button>
                  <hr className="border-gray-200" /> {/* Ayırıcı */}
                  <h3 className="text-lg font-bold text-gray-900">Tüm Onaylanmış Yatırımlara Biletleri Yeniden Ata</h3>
                  <p className="text-sm text-gray-700">
                    Bu işlem, mevcut tüm onaylanmış yatırımların bilet numaralarını sıfırlar ve yeniden atar.
                    Karışıklığı gidermek için kullanışlıdır.
                  </p>
                  <Button
                    onClick={handleBackfillTickets}
                    className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold py-3 text-lg"
                  >
                    <Ticket className="h-5 w-5 mr-2" /> Biletleri Yeniden Ata
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Etkinlik Geçmişi */}
            <TabsContent value="history">
              <Card className="bg-white border-2 border-gray-200 shadow-lg">
                <CardHeader className="bg-gray-50 border-b-2 border-gray-200">
                  <CardTitle className="text-gray-900 font-bold text-xl">Etkinlik Geçmişi</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  {/* Firma Seçimi */}
                  <div className="mb-6">
                    <label className="block text-gray-900 font-bold mb-2">Şirket Seçin</label>
                    <Select value={selectedCompanyForHistory} onValueChange={setSelectedCompanyForHistory}>
                      <SelectTrigger className="bg-gray-50 border-2 border-gray-300 text-gray-900 max-w-md">
                        <SelectValue placeholder="Geçmişini görmek istediğiniz şirketi seçin" />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-2 border-gray-300">
                        {companies.map((company) => (
                          <SelectItem key={company.id} value={company.name} className="text-gray-900 hover:bg-gray-100">
                            {company.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {!selectedCompanyForHistory ? (
                    <div className="text-center py-12">
                      <div className="text-gray-500 text-lg">
                        👆 Etkinlik geçmişini görüntülemek için yukarıdan bir şirket seçin
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="mb-4">
                        <h3 className="text-lg font-bold text-gray-900">
                          {selectedCompanyForHistory} Çekiliş Sonuçları
                        </h3>
                        <p className="text-gray-600">Toplam {sortedLotteryResults.length} kazanan</p>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-100">
                              <TableHead className="text-gray-900 font-bold">Sıra</TableHead>
                              <TableHead className="text-gray-900 font-bold">Kazanan</TableHead>
                              <TableHead className="text-gray-900 font-bold">Bilet No</TableHead>
                              <TableHead className="text-gray-900 font-bold">Ödül</TableHead>
                              <TableHead className="text-gray-900 font-bold">Etkinlik</TableHead>
                              <TableHead className="text-gray-900 font-bold">Tarih</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sortedLotteryResults.map((result, index) => (
                              <TableRow key={result.id} className="hover:bg-gray-50">
                                <TableCell className="text-center">
                                  <div className="flex items-center justify-center">{getPrizeIcon(result.prize)}</div>
                                </TableCell>
                                <TableCell className="text-gray-900 font-medium">{result.user_name}</TableCell>
                                <TableCell className="text-gray-900 font-mono font-bold text-blue-600">
                                  {result.ticket_number}
                                </TableCell>
                                <TableCell>
                                  <Badge className={`${getPrizeBadgeColor(result.prize)} font-bold text-lg px-3 py-1`}>
                                    {result.prize}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-gray-900">{result.event_name}</TableCell>
                                <TableCell className="text-gray-700">
                                  {new Date(result.created_at).toLocaleDateString("tr-TR")}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
