import { type NextRequest, NextResponse } from "next/server"
import { supabaseAdmin } from "@/lib/supabaseAdmin" // Admin client for direct public.users table access
import bcrypt from "bcryptjs" // Şifreleri hash'lemek için

export async function POST(request: NextRequest) {
  try {
    const { fullName, email, phone, password } = await request.json()

    // Validation
    if (!fullName || !email || !phone || !password) {
      return NextResponse.json({ error: "Tüm alanlar zorunludur" }, { status: 400 })
    }

    // E-posta zaten kayıtlı mı kontrol et
    const { data: existingUser, error: checkError } = await supabaseAdmin
      .from("users")
      .select("id")
      .eq("email", email)
      .maybeSingle()

    if (checkError) {
      console.error("Kayıt kontrol hatası:", checkError)
      return NextResponse.json({ error: "Kayıt kontrolü sırasında bir hata oluştu." }, { status: 500 })
    }
    if (existingUser) {
      return NextResponse.json({ error: "Bu e-posta adresi zaten kayıtlı." }, { status: 409 })
    }

    // Şifreyi hash'le
    const hashedPassword = await bcrypt.hash(password, 10) // 10 salt rounds

    // Public 'users' tablosuna ek bilgileri kaydet
    const { data, error: insertUserError } = await supabaseAdmin
      .from("users")
      .insert([
        {
          full_name: fullName,
          email: email,
          phone: phone,
          password_hash: hashedPassword, // Hash'lenmiş şifreyi kaydet
        },
      ])
      .select("id, full_name, email") // Sadece gerekli alanları seç
      .single()

    if (insertUserError) {
      console.error("Kullanıcı kaydı sırasında hata:", insertUserError)
      return NextResponse.json({ error: "Kayıt başarısız oldu: " + insertUserError.message }, { status: 500 })
    }

    return NextResponse.json({
      message: "Kayıt başarılı!",
      user: {
        id: data.id,
        fullName: data.full_name,
        email: data.email,
      },
    })
  } catch (error: any) {
    console.error("Kayıt API genel hatası:", error)
    return NextResponse.json({ error: "Sunucu hatası: " + error.message }, { status: 500 })
  }
}
