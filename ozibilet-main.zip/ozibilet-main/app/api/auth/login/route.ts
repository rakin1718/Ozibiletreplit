import { type NextRequest, NextResponse } from "next/server"
import { supabaseAdmin } from "@/lib/supabaseAdmin" // Admin client for direct public.users table access
import { cookies } from "next/headers" // Sunucu tarafı çerez yönetimi için
import bcrypt from "bcryptjs" // Şifre hash'lerini karşılaştırmak için

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "E-posta ve şifre zorunludur." }, { status: 400 })
    }

    let userRecord: any = null
    let role = "user"

    if (email === "admin@ozibilet.com") {
      // Admin girişi için admin_users tablosunu kontrol et
      const { data: adminUser, error: adminFetchError } = await supabaseAdmin
        .from("admin_users")
        .select("id, email, password_hash")
        .eq("email", email)
        .maybeSingle()

      if (adminFetchError || !adminUser) {
        console.error("Admin kullanıcı bulunamadı veya hata oluştu:", adminFetchError)
        return NextResponse.json({ error: "Geçersiz kimlik bilgileri." }, { status: 401 })
      }

      // Admin şifresini düz metin olarak karşılaştır (isteğiniz üzerine)
      if (password !== adminUser.password_hash) {
        return NextResponse.json({ error: "Geçersiz kimlik bilgileri." }, { status: 401 })
      }

      userRecord = adminUser
      role = "admin"

      // Admin oturum çerezini ayarla
      cookies().set("admin-session-token", userRecord.id, {
        // ID'yi çerezde sakla
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        path: "/",
        maxAge: 60 * 60 * 24 * 7, // 7 gün
      })
    } else {
      // Normal kullanıcı girişi için users tablosunu kontrol et
      const { data: regularUser, error: userFetchError } = await supabaseAdmin
        .from("users")
        .select("id, full_name, email, phone, password_hash")
        .eq("email", email)
        .maybeSingle()

      if (userFetchError || !regularUser) {
        console.error("Kullanıcı bulunamadı veya hata oluştu:", userFetchError)
        return NextResponse.json({ error: "Geçersiz kimlik bilgileri." }, { status: 401 })
      }

      // Normal kullanıcı şifresini hash ile karşılaştır
      const passwordMatch = await bcrypt.compare(password, regularUser.password_hash)

      if (!passwordMatch) {
        return NextResponse.json({ error: "Geçersiz kimlik bilgileri." }, { status: 401 })
      }

      userRecord = regularUser
      role = "user"

      // Normal kullanıcı oturum çerezini ayarla
      cookies().set("user-session-token", userRecord.id, {
        // ID'yi çerezde sakla
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        path: "/",
        maxAge: 60 * 60 * 24 * 7, // 7 gün
      })
    }

    return NextResponse.json({
      user: {
        id: userRecord.id,
        email: userRecord.email,
        fullName: userRecord.full_name || "Kullanıcı", // Admin için "Admin" olacak
        phone: userRecord.phone || "",
        role: role,
      },
    })
  } catch (err: any) {
    console.error("Giriş API genel hatası:", err)
    return NextResponse.json({ error: "Sunucu hatası: " + err.message }, { status: 500 })
  }
}
