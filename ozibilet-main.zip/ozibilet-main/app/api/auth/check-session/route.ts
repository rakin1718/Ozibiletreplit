import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { supabaseAdmin } from "@/lib/supabaseAdmin" // Admin client for direct public.users table access

export async function GET() {
  try {
    const adminSessionId = cookies().get("admin-session-token")?.value
    const userSessionId = cookies().get("user-session-token")?.value

    if (adminSessionId) {
      // Admin kullanıcısının bilgilerini çek
      const { data: adminUser, error: adminFetchError } = await supabaseAdmin
        .from("admin_users")
        .select("id, email")
        .eq("id", adminSessionId)
        .maybeSingle()

      if (adminFetchError || !adminUser) {
        console.error("Admin ID çekilirken hata:", adminFetchError)
        cookies().delete("admin-session-token") // Geçersiz çerezi temizle
        return NextResponse.json({ isLoggedIn: false }, { status: 200 })
      }

      return NextResponse.json(
        {
          isLoggedIn: true,
          user: {
            id: adminUser.id,
            email: adminUser.email,
            fullName: "Admin",
            phone: "",
            role: "admin",
          },
        },
        { status: 200 },
      )
    }

    if (userSessionId) {
      // Normal kullanıcının bilgilerini çek
      const { data: regularUser, error: userFetchError } = await supabaseAdmin
        .from("users")
        .select("id, full_name, email, phone")
        .eq("id", userSessionId)
        .maybeSingle()

      if (userFetchError || !regularUser) {
        console.error("Kullanıcı ID çekilirken hata:", userFetchError)
        cookies().delete("user-session-token") // Geçersiz çerezi temizle
        return NextResponse.json({ isLoggedIn: false }, { status: 200 })
      }

      return NextResponse.json(
        {
          isLoggedIn: true,
          user: {
            id: regularUser.id,
            email: regularUser.email,
            fullName: regularUser.full_name,
            phone: regularUser.phone,
            role: "user",
          },
        },
        { status: 200 },
      )
    }

    return NextResponse.json({ isLoggedIn: false }, { status: 200 })
  } catch (error: any) {
    console.error("Oturum kontrol edilirken beklenmeyen hata:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
