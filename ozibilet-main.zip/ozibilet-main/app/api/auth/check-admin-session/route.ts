import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { supabaseAdmin } from "@/lib/supabaseAdmin" // Admin client for direct public.users table access

export async function GET() {
  try {
    const adminSessionToken = cookies().get("admin-session-token")?.value

    if (adminSessionToken === "admin-logged-in") {
      // Admin kullanıcısının ID'sini admin_users tablosundan çek
      const { data: adminUser, error: adminFetchError } = await supabaseAdmin
        .from("admin_users")
        .select("id")
        .eq("email", "admin@ozibilet.com")
        .maybeSingle()

      if (adminFetchError || !adminUser) {
        console.error("Admin ID çekilirken hata:", adminFetchError)
        // Admin kullanıcısı bulunamazsa çerezi temizle
        cookies().delete("admin-session-token")
        return NextResponse.json({ isAdmin: false }, { status: 200 })
      }

      return NextResponse.json({ isAdmin: true, userId: adminUser.id }, { status: 200 })
    }

    return NextResponse.json({ isAdmin: false }, { status: 200 })
  } catch (error: any) {
    console.error("Admin oturumu kontrol edilirken beklenmeyen hata:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
