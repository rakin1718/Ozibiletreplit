import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabaseClient"

export async function GET() {
  try {
    const { data: users, error } = await supabase.from("users").select("id, full_name, email, phone, created_at") // Sadece gerekli alanları çek

    if (error) {
      console.error("Supabase GET users error:", error)
      return NextResponse.json({ error: "Kullanıcılar getirilemedi: " + error.message }, { status: 500 })
    }

    return NextResponse.json(users)
  } catch (error: any) {
    console.error("Users GET API general error:", error)
    return NextResponse.json({ error: "Sunucu hatası: " + error.message }, { status: 500 })
  }
}
