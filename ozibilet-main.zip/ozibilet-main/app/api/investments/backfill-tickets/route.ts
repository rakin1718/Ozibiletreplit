import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { supabaseAdmin } from "@/lib/supabaseAdmin" // Admin client for service role key

export async function POST(request: Request) {
  // Admin yetkilendirme kontrolü: Özel admin çerezini kontrol et
  const adminSessionId = cookies().get("admin-session-token")?.value
  if (!adminSessionId) {
    console.error("Yetkilendirme hatası: Admin yetkisi yok.")
    return NextResponse.json({ error: "Yetkilendirme hatası: Admin yetkisi yok." }, { status: 401 })
  }

  try {
    // 1. Tüm onaylanmış yatırımları bul (biletleri olsun veya olmasın)
    const { data: investmentsToUpdate, error: fetchError } = await supabaseAdmin
      .from("investments")
      .select("id, amount, tickets")
      .eq("status", "Onaylandı")

    if (fetchError) {
      console.error("Biletleri yeniden doldurmak için yatırımlar çekilirken hata:", fetchError)
      return NextResponse.json({ error: fetchError.message }, { status: 500 })
    }

    if (!investmentsToUpdate || investmentsToUpdate.length === 0) {
      return NextResponse.json({ message: "Bilet atanacak onaylanmış yatırım bulunamadı." }, { status: 200 })
    }

    // 2. Mevcut tüm bilet numaralarını topla (benzersizlik kontrolü için)
    const { data: allExistingTicketsData, error: existingTicketsError } = await supabaseAdmin
      .from("investments")
      .select("tickets")

    if (existingTicketsError) {
      console.error("Benzersizlik kontrolü için mevcut biletler çekilirken hata:", existingTicketsError)
    }

    const existingTicketNumbers = new Set<string>()
    if (allExistingTicketsData) {
      allExistingTicketsData.forEach((inv: any) => {
        if (inv.tickets && Array.isArray(inv.tickets)) {
          inv.tickets.forEach((ticket: string) => existingTicketNumbers.add(ticket))
        }
      })
    }
    console.log(`Benzersizlik kontrolü için ${existingTicketNumbers.size} mevcut bilet bulundu.`)

    let updatedCount = 0
    const errors = []

    // 3. Her onaylanmış yatırım için biletleri sıfırla ve yeniden oluştur
    for (const investment of investmentsToUpdate) {
      try {
        const numberOfTickets = Math.floor(investment.amount / 1000)
        const generatedTicketsSet = new Set<string>()
        let attempts = 0
        const maxAttempts = numberOfTickets * 100 // Sonsuz döngüyü önlemek için daha fazla deneme

        while (generatedTicketsSet.size < numberOfTickets && attempts < maxAttempts) {
          // Sadece sayılardan oluşan 8 haneli bilet numarası oluştur
          const newTicket = Math.floor(10000000 + Math.random() * 90000000).toString()
          if (!existingTicketNumbers.has(newTicket)) {
            generatedTicketsSet.add(newTicket)
            existingTicketNumbers.add(newTicket) // Yeni oluşturulan bileti de mevcut setine ekle
          }
          attempts++
        }

        if (generatedTicketsSet.size < numberOfTickets) {
          console.warn(
            `Yatırım ${investment.id} için yeterli benzersiz bilet oluşturulamadı. İstenen: ${numberOfTickets}, Oluşturulan: ${generatedTicketsSet.size}`,
          )
          errors.push(`Yatırım ${investment.id} için yeterli bilet oluşturulamadı.`)
          continue // Bu yatırımı atla
        }

        const generatedTickets = Array.from(generatedTicketsSet)

        // Biletleri JSONB olarak güncelle ve approved_at'ı ayarla
        const { error: updateError } = await supabaseAdmin
          .from("investments")
          .update({ tickets: generatedTickets, approved_at: new Date().toISOString() })
          .eq("id", investment.id)

        if (updateError) {
          console.error(`Yatırım ${investment.id} için biletler güncellenirken hata:`, updateError)
          errors.push(`Yatırım ${investment.id} biletleri güncellenemedi: ${updateError.message}`)
        } else {
          updatedCount++
          console.log(`Yatırım ${investment.id} için biletler başarıyla yeniden atandı.`)
        }
      } catch (innerError: any) {
        console.error(`Yatırım ${investment.id} işlenirken beklenmeyen hata:`, innerError)
        errors.push(`Yatırım ${investment.id} işlenirken beklenmeyen hata: ${innerError.message}`)
      }
    }

    if (errors.length > 0) {
      return NextResponse.json(
        {
          message: `Bilet atama işlemi tamamlandı. ${updatedCount} yatırım güncellendi, ancak bazı hatalar oluştu.`,
          errors: errors,
        },
        { status: 200 },
      )
    }

    return NextResponse.json(
      { message: `${updatedCount} yatırım için biletler başarıyla yeniden atandı.` },
      { status: 200 },
    )
  } catch (error: any) {
    console.error("Biletleri yeniden doldurma API'si sırasında beklenmeyen hata:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
