import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { searchParams } = new URL(request.url)
  const company = searchParams.get("company")

  try {
    let query = supabase
      .from("investments")
      .select("*, users(full_name, email)")
      .order("created_at", { ascending: false })

    if (company) {
      query = query.eq("company", company)
    }

    const { data: investments, error } = await query

    if (error) {
      console.error("Yatırımlar çekilirken hata:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Kullanıcıya göre yatırımları grupla ve birleştir
    const groupedInvestments = new Map()

    investments.forEach((inv: any) => {
      const userId = inv.user_id
      const userName = inv.users?.full_name || "Bilinmiyor"
      const userEmail = inv.users?.email || "Bilinmiyor"

      if (groupedInvestments.has(userId)) {
        const existing = groupedInvestments.get(userId)

        // Tutarları topla
        existing.amount += inv.amount

        // Biletleri birleştir (sadece onaylanmış yatırımlardan)
        if (inv.status === "Onaylandı" && inv.tickets && Array.isArray(inv.tickets)) {
          existing.tickets = [...(existing.tickets || []), ...inv.tickets]
        }

        // En son yatırım tarihini al
        if (new Date(inv.created_at) > new Date(existing.created_at)) {
          existing.created_at = inv.created_at
        }

        // Durum önceliği: Onaylandı > Bekliyor > Reddedildi
        if (existing.status === "Reddedildi" && inv.status !== "Reddedildi") {
          existing.status = inv.status
        } else if (existing.status === "Bekliyor" && inv.status === "Onaylandı") {
          existing.status = inv.status
        }

        // ŞansCasino ID'lerini birleştir (virgülle ayırarak)
        if (inv.sans_username && !existing.sans_username.includes(inv.sans_username)) {
          existing.sans_username += `, ${inv.sans_username}`
        }

        // Yatırım sayısını artır
        existing.investment_count += 1
      } else {
        groupedInvestments.set(userId, {
          id: inv.id,
          user_id: userId,
          user_name: userName,
          user_email: userEmail,
          amount: inv.amount,
          sans_username: inv.sans_username,
          status: inv.status,
          company: inv.company,
          created_at: inv.created_at,
          tickets: inv.status === "Onaylandı" && inv.tickets ? [...inv.tickets] : [],
          investment_count: 1,
        })
      }
    })

    const formattedInvestments = Array.from(groupedInvestments.values())

    return NextResponse.json({ investments: formattedInvestments })
  } catch (error: any) {
    console.error("Yatırımlar çekilirken beklenmeyen hata:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { userId, amount, sansUsername, company } = await request.json() // sansUsername burada Şanscasino ID'sini tutacak

  if (!userId || !amount || !sansUsername || !company) {
    return NextResponse.json({ error: "Tüm alanlar doldurulmalıdır." }, { status: 400 })
  }

  // sansUsername'in sadece sayı içerdiğini doğrula
  if (!/^\d+$/.test(sansUsername)) {
    return NextResponse.json({ error: "ŞansCasino ID sadece sayılardan oluşmalıdır." }, { status: 400 })
  }

  try {
    const { data, error } = await supabase
      .from("investments")
      .insert([
        {
          user_id: userId,
          amount: amount,
          sans_username: sansUsername, // Şanscasino ID'si olarak kaydedilecek
          company: company,
          status: "Bekliyor",
        },
      ])
      .select()

    if (error) {
      console.error("Yatırım eklenirken hata:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ message: "Yatırım talebiniz başarıyla alındı!", data }, { status: 201 })
  } catch (error: any) {
    console.error("Yatırım POST sırasında beklenmeyen hata:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  const supabase = createRouteHandlerClient({ cookies })
  const { id, status } = await request.json()

  if (!id || !status) {
    return NextResponse.json({ error: "ID ve durum gerekli." }, { status: 400 })
  }

  if (!["Onaylandı", "Reddedildi"].includes(status)) {
    return NextResponse.json({ error: "Geçersiz durum." }, { status: 400 })
  }

  try {
    // Önce yatırımın mevcut durumunu ve biletlerini kontrol et
    const { data: currentInvestment, error: currentInvestmentError } = await supabase
      .from("investments")
      .select("status, amount, tickets")
      .eq("id", id)
      .single()

    if (currentInvestmentError || !currentInvestment) {
      console.error("Güncelleme için mevcut yatırım çekilirken hata:", currentInvestmentError)
      return NextResponse.json({ error: "Yatırım bilgisi alınamadı veya bulunamadı." }, { status: 404 })
    }

    // Eğer zaten onaylanmış ve biletleri varsa, tekrar bilet oluşturma
    if (status === "Onaylandı" && currentInvestment.status === "Onaylandı" && currentInvestment.tickets) {
      console.log(`Yatırım ${id} zaten onaylandı ve biletleri mevcut. Yeni bilet oluşturulmadı.`)
      return NextResponse.json(
        { message: "Yatırım durumu zaten onaylandı ve biletleri mevcut.", data: currentInvestment },
        { status: 200 },
      )
    }

    // Durumu güncelle
    const { data, error } = await supabase.from("investments").update({ status: status }).eq("id", id).select()

    if (error) {
      console.error("Yatırım durumu güncellenirken hata:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    if (!data || data.length === 0) {
      return NextResponse.json({ error: "Yatırım bulunamadı veya güncellenemedi." }, { status: 404 })
    }

    if (status === "Onaylandı") {
      console.log(`Yatırım ${id} onaylandı. Biletler oluşturulmaya çalışılıyor...`)
      const numberOfTickets = Math.floor(currentInvestment.amount / 1000)
      console.log(`Yatırım ${id} için ${numberOfTickets} bilet hesaplandı (tutar: ${currentInvestment.amount}).`)

      const generatedTicketsSet = new Set<string>()
      const { data: allExistingTicketsData, error: existingTicketsError } = await supabase
        .from("investments")
        .select("tickets")

      if (existingTicketsError) {
        console.error("Benzersizlik kontrolü için mevcut biletler çekilirken hata:", existingTicketsError)
      }

      const existingTicketNumbers = new Set<string>()
      if (allExistingTicketsData) {
        allExistingTicketsData.forEach((inv: any) => {
          if (inv.tickets && Array.isArray(inv.tickets)) {
            inv.tickets.forEach((ticket: string) => existingTicketNumbers.add(ticket))
          }
        })
      }
      console.log(`Benzersizlik kontrolü için ${existingTicketNumbers.size} mevcut bilet bulundu.`)

      let attempts = 0
      const maxAttempts = numberOfTickets * 10 // Daha fazla deneme hakkı
      while (generatedTicketsSet.size < numberOfTickets && attempts < maxAttempts) {
        // Sadece sayılardan oluşan 8 haneli bilet numarası oluştur
        const newTicket = Math.floor(10000000 + Math.random() * 90000000).toString()
        if (!existingTicketNumbers.has(newTicket)) {
          generatedTicketsSet.add(newTicket)
          existingTicketNumbers.add(newTicket) // Bu partideki tekrarları önlemek için yerel setimize ekle
        }
        attempts++
      }

      if (generatedTicketsSet.size < numberOfTickets) {
        console.warn(
          `Yatırım ${id} için yeterli benzersiz bilet oluşturulamadı. İstenen: ${numberOfTickets}, Oluşturulan: ${generatedTicketsSet.size}`,
        )
      }

      const generatedTickets = Array.from(generatedTicketsSet)
      console.log(`Yatırım ${id} için oluşturulan biletler:`, generatedTickets)

      // Biletleri JSONB olarak güncelle ve approved_at'ı ayarla
      const { error: updateTicketsError } = await supabase
        .from("investments")
        .update({ tickets: generatedTickets, approved_at: new Date().toISOString() })
        .eq("id", id)

      if (updateTicketsError) {
        console.error("Yatırım için biletler güncellenirken hata:", id, updateTicketsError)
        return NextResponse.json({ error: `Biletler güncellenemedi: ${updateTicketsError.message}` }, { status: 500 })
      }
      console.log(`Yatırım ${id} için biletler başarıyla güncellendi.`)
    }

    return NextResponse.json({ message: "Yatırım durumu başarıyla güncellendi.", data }, { status: 200 })
  } catch (error: any) {
    console.error("Yatırım PUT sırasında beklenmeyen hata:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
