import { NextResponse } from "next/server"
import { cookies } from "next/headers" // Sunucu tarafı çerez yönetimi için
import { supabaseAdmin } from "@/lib/supabaseAdmin" // Admin client for service role key

// Şirket ödül yapıları
const PRIZE_STRUCTURES: { [key: string]: { rank: number; count: number; prize: number; description: string }[] } = {
  ŞansCasino: [
    { rank: 1, count: 1, prize: 50000, description: "1. Sıra" },
    { rank: 2, count: 1, prize: 30000, description: "2. Sıra" },
    { rank: 3, count: 1, prize: 15000, description: "3. Sıra" },
    { rank: 4, count: 1, prize: 10000, description: "4. Sıra" },
    { rank: 5, count: 1, prize: 5000, description: "5. Sıra" },
    { rank: 6, count: 10, prize: 2000, description: "Teşekkür Ödülü" }, // 10 kişiye güncellendi
  ],
}

export async function POST(request: Request) {
  // Admin yetkilendirme kontrolü: Özel admin çerezini kontrol et
  const adminSessionId = cookies().get("admin-session-token")?.value
  if (!adminSessionId) {
    console.error("Yetkilendirme hatası: Admin yetkisi yok.")
    return NextResponse.json({ error: "Yetkilendirme hatası: Admin yetkisi yok." }, { status: 401 })
  }

  const { company } = await request.json()

  if (!company) {
    return NextResponse.json({ error: "Şirket gerekli." }, { status: 400 })
  }

  // Ödül yapısını al
  const prizeStructure = PRIZE_STRUCTURES[company]
  if (!prizeStructure) {
    return NextResponse.json({ error: `${company} için ödül yapısı bulunamadı.` }, { status: 400 })
  }

  try {
    // Seçilen şirkete ait onaylanmış yatırımları getir
    const { data: approvedInvestments, error: investmentsError } = await supabaseAdmin
      .from("investments")
      .select("user_id, amount, sans_username, users(full_name, email)")
      .eq("status", "Onaylandı")
      .eq("company", company)

    if (investmentsError) {
      console.error("Yatırımlar çekilirken hata:", investmentsError)
      return NextResponse.json({ error: investmentsError.message }, { status: 500 })
    }

    if (!approvedInvestments || approvedInvestments.length === 0) {
      return NextResponse.json({ error: `${company} için onaylanmış yatırım bulunamadı.` }, { status: 404 })
    }

    // Daha önce bu şirketten kazanan kullanıcıları kontrol et
    const { data: previousWinners, error: winnersError } = await supabaseAdmin
      .from("lottery_results")
      .select("user_id")
      .eq("event_name", `${company} Büyük Çekiliş`)

    if (winnersError) {
      console.error("Önceki kazananlar kontrol edilirken hata:", winnersError)
      return NextResponse.json({ error: winnersError.message }, { status: 500 })
    }

    const previousWinnerIds = new Set(previousWinners?.map((w) => w.user_id) || [])

    // Biletleri oluştur (daha önce kazanmayanlar için)
    const tickets: { userId: string; userName: string; userEmail: string; ticketNumber: string }[] = []

    approvedInvestments.forEach((investment: any) => {
      // Eğer bu kullanıcı daha önce bu şirketten kazanmamışsa
      if (!previousWinnerIds.has(investment.user_id)) {
        const numberOfTickets = Math.floor(investment.amount / 1000)
        const userName = investment.users?.full_name || "Bilinmiyor"
        const userEmail = investment.users?.email || "Bilinmiyor"

        for (let i = 0; i < numberOfTickets; i++) {
          // Sadece sayılardan oluşan 8 haneli bilet numarası oluştur
          const newTicket = Math.floor(10000000 + Math.random() * 90000000).toString()
          tickets.push({
            userId: investment.user_id,
            userName: userName,
            userEmail: userEmail,
            ticketNumber: newTicket,
          })
        }
      }
    })

    if (tickets.length === 0) {
      return NextResponse.json(
        { error: `${company} için uygun katılımcı bulunamadı. Tüm kullanıcılar daha önce kazanmış olabilir.` },
        { status: 400 },
      )
    }

    // Çekiliş yap - her ödül kategorisi için
    const winners: any[] = []
    const usedTickets = new Set<string>()
    const usedParticipants = new Set<string>()

    for (const prizeLevel of prizeStructure) {
      for (let i = 0; i < prizeLevel.count; i++) {
        // Kullanılmamış biletleri filtrele
        const availableTickets = tickets.filter(
          (ticket) => !usedTickets.has(ticket.ticketNumber) && !usedParticipants.has(ticket.userId),
        )

        if (availableTickets.length === 0) break

        // Rastgele kazanan seç
        const randomIndex = Math.floor(Math.random() * availableTickets.length)
        const winnerTicket = availableTickets[randomIndex]

        // Kazananı kaydet
        const { data: lotteryResult, error: lotteryError } = await supabaseAdmin
          .from("lottery_results")
          .insert([
            {
              user_id: winnerTicket.userId,
              user_name: winnerTicket.userName,
              ticket_number: winnerTicket.ticketNumber,
              prize: `${prizeLevel.prize.toLocaleString("tr-TR")} TL`,
              event_name: `${company} Büyük Çekiliş`,
            },
          ])
          .select()

        if (lotteryError) {
          console.error("Kazanan kaydedilirken hata:", lotteryError)
          continue
        }

        winners.push({
          id: lotteryResult[0].id,
          userName: winnerTicket.userName,
          userEmail: winnerTicket.userEmail,
          ticketNumber: winnerTicket.ticketNumber,
          prize: `${prizeLevel.prize.toLocaleString("tr-TR")} TL`,
          prizeAmount: prizeLevel.prize,
          eventName: `${company} Büyük Çekiliş`,
          rank: prizeLevel.rank,
        })

        // Kullanılan bilet ve katılımcıyı işaretle
        usedTickets.add(winnerTicket.ticketNumber)
        usedParticipants.add(winnerTicket.userId)
      }
    }

    return NextResponse.json({
      message: `${company} çekilişi başarıyla yapıldı! ${winners.length} kazanan belirlendi.`,
      winners: winners,
      totalTickets: tickets.length,
    })
  } catch (error: any) {
    console.error("Çekiliş sırasında beklenmeyen hata:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
