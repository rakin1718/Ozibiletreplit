import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const supabase = createRouteHandlerClient({ cookies })

  try {
    const { data: lotteryResults, error } = await supabase
      .from("lottery_results")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50) // Daha fazla sonuç getir

    if (error) {
      console.error("Error fetching lottery results:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ results: lotteryResults })
  } catch (error: any) {
    console.error("Unexpected error fetching lottery results:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
