"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/auth-context"
import AppHeader from "@/components/app-header"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, XCircle } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

interface Investment {
  id: string
  user_id: string
  amount: number
  sans_username: string // Bu alan artık Şanscasino ID'sini tutacak
  status: "Bekliyor" | "Onaylandı" | "Reddedildi"
  company: string
  created_at: string
  tickets?: string[] | null // Eklendi
}

export default function DashboardPage() {
  const { isLoggedIn, user, userRole, loading: authLoading } = useAuth()
  const router = useRouter()
  const [investments, setInvestments] = useState<Investment[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!authLoading && !isLoggedIn) {
      router.push("/auth/login")
      return
    }
    if (!authLoading && isLoggedIn && userRole === "admin") {
      router.push("/admin")
      return
    }

    if (isLoggedIn && user?.id) {
      fetchUserInvestments(user.id)
    }
  }, [isLoggedIn, user, userRole, authLoading, router])

  const fetchUserInvestments = async (userId: string) => {
    try {
      const response = await fetch(`/api/investments/user?userId=${userId}`)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Yatırımlar getirilemedi.")
      }

      setInvestments(data.investments)
    } catch (err: any) {
      setError(err.message || "Yatırımlar yüklenirken bir hata oluştu.")
    } finally {
      setLoading(false)
    }
  }

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100">
        <Loader2 className="h-12 w-12 animate-spin text-purple-600" />
      </div>
    )
  }

  if (!isLoggedIn) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100">
      <AppHeader
        logoSrc="/images/ozi-bilet-logo.png"
        logoAlt="Ozi Bilet Logo"
        logoWidth={250}
        logoHeight={100}
        logoClassName="object-contain h-16 md:h-28"
      />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto space-y-8">
          <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Hoş Geldiniz, {user?.fullName}!
          </h1>

          {error && (
            <Alert variant="destructive" className="bg-red-50 border-2 border-red-300">
              <XCircle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-800 font-bold">Hata!</AlertTitle>
              <AlertDescription className="text-red-700">{error}</AlertDescription>
            </Alert>
          )}

          <Card className="bg-white border-2 border-gray-200 shadow-lg">
            <CardHeader className="bg-gray-50 border-b-2 border-gray-200">
              <CardTitle className="text-2xl font-bold text-gray-900">Yatırımlarım</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
                  <p className="ml-4 text-gray-700">Yatırımlarınız yükleniyor...</p>
                </div>
              ) : investments.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-700 mb-4">Henüz bir yatırımınız bulunmamaktadır.</p>
                  <Link href="/">
                    <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-2">
                      Etkinliklere Göz At
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-100">
                        <TableHead className="text-gray-900 font-bold">Tarih</TableHead>
                        <TableHead className="text-gray-900 font-bold">Şirket</TableHead>
                        <TableHead className="text-gray-900 font-bold">Yatırım Tutarı</TableHead>
                        <TableHead className="text-gray-900 font-bold">ŞansCasino ID</TableHead>
                        <TableHead className="text-gray-900 font-bold">Durum</TableHead>
                        <TableHead className="text-gray-900 font-bold">Biletler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {investments.map((investment) => (
                        <TableRow key={investment.id} className="hover:bg-gray-50">
                          <TableCell className="text-gray-900">
                            {new Date(investment.created_at).toLocaleDateString("tr-TR")}
                          </TableCell>
                          <TableCell className="text-gray-900">{investment.company}</TableCell>
                          <TableCell className="text-gray-900 font-semibold">
                            {investment.amount.toLocaleString("tr-TR")} TL
                          </TableCell>
                          <TableCell className="text-gray-900">{investment.sans_username}</TableCell>
                          <TableCell>
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-bold ${
                                investment.status === "Onaylandı"
                                  ? "bg-green-100 text-green-800 border border-green-300"
                                  : investment.status === "Bekliyor"
                                    ? "bg-yellow-100 text-yellow-800 border border-yellow-300"
                                    : "bg-red-100 text-red-800 border border-red-300"
                              }`}
                            >
                              {investment.status}
                            </span>
                          </TableCell>
                          <TableCell className="text-gray-900">
                            {investment.status === "Onaylandı" &&
                            investment.tickets &&
                            Array.isArray(investment.tickets) &&
                            investment.tickets.length > 0 ? (
                              <div className="flex flex-col items-start">
                                <span className="font-mono text-blue-600 font-bold">
                                  {investment.tickets.slice(0, 3).join(", ")}
                                  {investment.tickets.length > 3 && "..."}
                                </span>
                                {investment.tickets.length > 3 && (
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button
                                        variant="link"
                                        size="sm"
                                        className="p-0 h-auto text-xs text-purple-600 hover:underline"
                                      >
                                        Tümünü Gör ({investment.tickets.length})
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent className="sm:max-w-[425px] md:max-w-lg lg:max-w-xl">
                                      <DialogHeader>
                                        <DialogTitle>Bilet Numaralarınız</DialogTitle>
                                      </DialogHeader>
                                      <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                                        {investment.tickets.map((ticket, idx) => (
                                          <Badge
                                            key={idx}
                                            variant="secondary"
                                            className="text-center text-sm font-mono"
                                          >
                                            {ticket}
                                          </Badge>
                                        ))}
                                      </div>
                                    </DialogContent>
                                  </Dialog>
                                )}
                              </div>
                            ) : investment.status === "Bekliyor" ? (
                              <span className="text-gray-500">Onay bekliyor</span>
                            ) : (
                              <span className="text-gray-500">Bilet yok</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
