"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"
import { getEventBySlug } from "@/lib/eventData"
import { useAuth } from "@/context/auth-context"
import AppHeader from "@/components/app-header"

interface EventPageProps {
  params: { company: string }
}

export default function EventPage({ params }: EventPageProps) {
  const { company: eventSlug } = params
  const router = useRouter()
  const { isLoggedIn, user, loading: authLoading } = useAuth()
  const userRole = user?.role

  const [sansUsername, setSansUsername] = useState("")
  const [amount, setAmount] = useState("")
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [loading, setLoading] = useState(false)

  const event = getEventBySlug(eventSlug)

  useEffect(() => {
    if (!authLoading) {
      if (!isLoggedIn) {
        router.push("/auth/login")
        return
      }
      if (userRole === "admin") {
        router.push("/admin")
        return
      }
    }
    if (!event) {
      router.push("/") // Etkinlik bulunamazsa ana sayfaya yönlendir
    }
  }, [event, authLoading, isLoggedIn, userRole, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    setLoading(true)

    if (!user?.id) {
      setMessage({ type: "error", text: "Kullanıcı oturumu bulunamadı. Lütfen tekrar giriş yapın." })
      setLoading(false)
      return
    }

    if (!event) {
      setMessage({ type: "error", text: "Etkinlik bulunamadı." })
      setLoading(false)
      return
    }

    const parsedAmount = Number.parseFloat(amount)
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setMessage({ type: "error", text: "Geçerli bir yatırım tutarı girin." })
      setLoading(false)
      return
    }

    try {
      const response = await fetch("/api/investments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          amount: parsedAmount,
          sansUsername,
          company: event.company,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setMessage({ type: "success", text: data.message || "Yatırım talebiniz başarıyla alındı!" })
        setSansUsername("")
        setAmount("")
      } else {
        setMessage({ type: "error", text: data.error || "Yatırım talebi gönderilirken bir hata oluştu." })
      }
    } catch (err: any) {
      setMessage({ type: "error", text: "Bir hata oluştu. Lütfen daha sonra tekrar deneyin." })
      console.error("Investment submission error:", err)
    } finally {
      setLoading(false)
    }
  }

  if (authLoading || !isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100">
        <Loader2 className="h-12 w-12 animate-spin text-purple-600" />
        <p className="ml-4 text-lg text-purple-700">Yükleniyor...</p>
      </div>
    )
  }

  if (!event) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100 p-4">
        <Alert variant="destructive" className="max-w-md">
          <XCircle className="h-4 w-4" />
          <AlertTitle>Hata!</AlertTitle>
          <AlertDescription>Etkinlik bulunamadı.</AlertDescription>
        </Alert>
        <Button onClick={() => router.push("/")} className="mt-4">
          Ana Sayfaya Dön
        </Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100">
      <AppHeader
        logoSrc="/images/ozi-bilet-logo.png"
        logoAlt="Ozi Bilet Logo"
        logoWidth={250}
        logoHeight={100}
        logoClassName="object-contain h-16 md:h-28"
      />

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <Card className="backdrop-blur-md bg-white/80 shadow-xl">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Image
                  src={event.logo || "/placeholder.svg"}
                  alt={`${event.company} Logo`}
                  width={150}
                  height={100}
                  className="object-contain"
                />
              </div>
              <CardTitle className="text-3xl font-bold text-purple-800">{event.company} Etkinliği</CardTitle>
              <CardDescription className="text-gray-600">
                {event.name} - {event.totalPrize.toLocaleString("tr-TR")} TL Ödül Havuzu
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4 text-gray-700">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Etkinlik Detayları</h3>
                  <p>
                    <span className="font-medium">Başlangıç Tarihi:</span>{" "}
                    {new Date(event.startDate).toLocaleDateString("tr-TR")}
                  </p>
                  <p>
                    <span className="font-medium">Bitiş Tarihi:</span>{" "}
                    {new Date(event.endDate).toLocaleDateString("tr-TR")}
                  </p>
                  <p>
                    <span className="font-medium">Katılım Şartı:</span> Her 1000 TL yatırım bir bilet kazandırır.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Ödül Dağılımı</h3>
                  {event.prizeStructure.map((prize, index) => (
                    <p key={index}>
                      {prize.count}x {prize.prize.toLocaleString("tr-TR")} TL - {prize.description}
                    </p>
                  ))}
                </div>
              </div>

              <hr className="border-purple-200" />

              <h2 className="text-2xl font-bold text-center text-purple-800">Yatırım Yap ve Bilet Kazan</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="sans-username">Şanscasino Kullanıcı Adınız</Label>
                  <Input
                    id="sans-username"
                    type="text"
                    placeholder="Şanscasino kullanıcı adınızı girin"
                    required
                    value={sansUsername}
                    onChange={(e) => setSansUsername(e.target.value)}
                    className="bg-white/70 border-purple-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Yatırım Miktarı (TL)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Örn: 1000, 2500"
                    required
                    min="1"
                    step="any"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="bg-white/70 border-purple-200"
                  />
                </div>
                {message && (
                  <Alert
                    variant={message.type === "error" ? "destructive" : "default"}
                    className={message.type === "success" ? "bg-green-100 border-green-400 text-green-700" : ""}
                  >
                    {message.type === "success" ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                    <AlertTitle>{message.type === "success" ? "Başarılı!" : "Hata!"}</AlertTitle>
                    <AlertDescription>{message.text}</AlertDescription>
                  </Alert>
                )}
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-2"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Gönderiliyor...
                    </>
                  ) : (
                    "Yatırım Talebi Gönder"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
