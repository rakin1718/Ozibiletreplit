"use client"

import type React from "react"
import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown, ExternalLink, Calculator } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import AppHeader from "@/components/app-header"
import { useAuth } from "@/context/auth-context" // Corrected import path
import { useRouter } from "next/navigation"

export default function EventDetailPage() {
  const [isDescriptionOpen, setIsDescriptionOpen] = useState(false)
  const [investmentAmount, setInvestmentAmount] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState("")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [sansId, setSansId] = useState("") // sansUsername yerine sansId kullanıldı
  const { isLoggedIn: authIsLoggedIn, userRole, loading: authLoading, user } = useAuth() // user objesini ekledik
  const router = useRouter()

  useEffect(() => {
    if (!authLoading) {
      if (!authIsLoggedIn) {
        router.push("/auth/login")
        return
      }
      if (userRole === "admin") {
        router.push("/admin")
        return
      }
    }
    setIsLoggedIn(authIsLoggedIn)
  }, [authIsLoggedIn, userRole, authLoading, router])

  const calculateTickets = (amount: number) => {
    return Math.floor(amount / 1000)
  }

  const handleInvestmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const amount = Number.parseFloat(investmentAmount)

    if (!amount || amount < 1000) {
      setSubmitMessage("Minimum yatırım tutarı 1000 TL olmalıdır.")
      return
    }

    // sansId'nin sadece sayı içerdiğini ve boş olmadığını kontrol et
    if (!sansId.trim() || !/^\d+$/.test(sansId.trim())) {
      setSubmitMessage("ŞansCasino ID sadece sayılardan oluşmalı ve boş olmamalıdır.")
      return
    }

    setIsSubmitting(true)

    try {
      // userId'yi localStorage'dan almak yerine useAuth hook'undan alıyoruz
      const userId = user?.id // Burası güncellendi

      if (!userId) {
        setSubmitMessage("Kullanıcı oturumu bulunamadı. Lütfen tekrar giriş yapın.")
        setIsSubmitting(false)
        return
      }

      const response = await fetch("/api/investments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: amount,
          sansUsername: sansId.trim(), // Backend'de hala sansUsername olarak geçiyor
          userId: userId, // Güncellenmiş userId
          company: "ŞansCasino",
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Yatırım gönderilemedi")
      }

      const tickets = Math.floor(amount / 1000)
      setSubmitMessage(`Yatırımınız: ${amount.toLocaleString("tr-TR")} TL – Onay Bekliyor (${tickets} bilet hakkı)`)
      setInvestmentAmount("")
      setSansId("") // sansId'yi temizle
    } catch (error: any) {
      console.error("Yatırım gönderme hatası:", error)
      setSubmitMessage("Yatırım gönderilirken hata oluştu: " + error.message)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100">
      <AppHeader
        logoSrc="/images/ozi-bilet-logo.png"
        logoAlt="Ozi Bilet Logo"
        logoWidth={250}
        logoHeight={100}
        logoClassName="object-contain h-16 md:h-28"
      />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Logo Section */}
          <div className="text-center">
            <div className="w-56 h-36 mx-auto mb-6 flex items-center justify-center">
              <Image
                src="/images/sanscasino-new-logo.png"
                alt="ŞansCasino Logo"
                width={224}
                height={144}
                className="object-contain w-full h-full"
              />
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent mb-2">
              ŞansCasino Büyük Ödül Etkinliği
            </h1>
          </div>

          {/* Event Description */}
          <Card className="backdrop-blur-md bg-white/40 border-white/20 shadow-xl">
            <Collapsible open={isDescriptionOpen} onOpenChange={setIsDescriptionOpen}>
              <CollapsibleTrigger asChild>
                <CardHeader className="cursor-pointer hover:bg-white/10 transition-colors">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-2xl text-gray-800">Etkinlik Detayları</CardTitle>
                    <ChevronDown className={`h-6 w-6 transition-transform ${isDescriptionOpen ? "rotate-180" : ""}`} />
                  </div>
                </CardHeader>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent className="pt-0">
                  <div className="space-y-6">
                    <div className="bg-gradient-to-r from-yellow-100 to-orange-100 p-6 rounded-lg border border-yellow-200">
                      <h3 className="text-xl font-semibold text-gray-800 mb-4">🎯 Toplam Ödül Havuzu: 150.000 TL</h3>
                      <p className="text-gray-700 mb-4">
                        ⚡ <strong>Her 1000 TL yatırım = 1 bilet</strong>
                      </p>
                      <p className="text-gray-700">
                        🎲 Çekiliş tamamen şeffaf ve adil bir şekilde gerçekleştirilir. Tüm katılımcılar eşit şansa
                        sahiptir!
                      </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-white/50 p-6 rounded-lg">
                        <h4 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">🏆 Ödül Dağılımı:</h4>
                        <ul className="space-y-2 text-gray-700">
                          <li className="flex justify-between items-center p-2 bg-yellow-50 rounded">
                            <span>🥇 1. Sıra:</span>
                            <span className="font-bold text-yellow-600">50.000 TL</span>
                          </li>
                          <li className="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <span>🥈 2. Sıra:</span>
                            <span className="font-bold text-gray-600">30.000 TL</span>
                          </li>
                          <li className="flex justify-between items-center p-2 bg-orange-50 rounded">
                            <span>🥉 3. Sıra:</span>
                            <span className="font-bold text-orange-600">15.000 TL</span>
                          </li>
                          <li className="flex justify-between items-center p-2 bg-blue-50 rounded">
                            <span>🎖️ 4. Sıra:</span>
                            <span className="font-bold text-blue-600">10.000 TL</span>
                          </li>
                          <li className="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span>🏅 5. Sıra:</span>
                            <span className="font-bold text-green-600">5.000 TL</span>
                          </li>
                          <li className="flex justify-between items-center p-2 bg-purple-50 rounded">
                            <span>🎁 20 Kişiye:</span>
                            <span className="font-bold text-purple-600">2.000 TL</span>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-red-50 p-6 rounded-lg border border-red-200">
                        <h4 className="font-semibold text-red-800 mb-2 flex items-center gap-2">
                          ⏰ Son Katılım Tarihi:
                        </h4>
                        <p className="text-red-700 text-2xl font-bold">6 Ağustos 2025</p>
                        <p className="text-red-600 mb-4">Saat 23:59</p>

                        <div className="bg-white/70 p-4 rounded-lg">
                          <h5 className="font-semibold text-gray-800 mb-2">📋 Katılım Şartları:</h5>
                          <ul className="text-sm text-gray-700 space-y-1">
                            <li>• ŞansCasino'da aktif hesabınız olmalı</li>
                            <li>• Minimum 1000 TL yatırım gerekli</li>
                            <li>• Yatırım onaylandıktan sonra biletiniz aktif olur</li>
                            <li>• Çekiliş canlı yayında gerçekleştirilir</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                      <h4 className="font-semibold text-blue-800 mb-3 flex items-center gap-2">💡 Nasıl Çalışır?</h4>
                      <div className="grid md:grid-cols-2 gap-4 text-sm text-blue-700">
                        <div>
                          <p className="font-semibold mb-2">1️⃣ Kayıt Olun</p>
                          <p>ŞansCasino'ya kayıt olun ve hesabınızı aktifleştirin.</p>
                        </div>
                        <div>
                          <p className="font-semibold mb-2">2️⃣ Yatırım Yapın</p>
                          <p>Bu sayfadan yatırım talebinizi gönderin.</p>
                        </div>
                        <div>
                          <p className="font-semibold mb-2">3️⃣ Onay Bekleyin</p>
                          <p>Yatırımınız kontrol edilip onaylanacak.</p>
                        </div>
                        <div>
                          <p className="font-semibold mb-2">4️⃣ Çekilişe Katılın</p>
                          <p>Onay sonrası otomatik olarak çekilişe dahil olursunuz.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>

          {/* Registration Button */}
          <div className="text-center">
            <a href="https://t.ly/ozibey" target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-4 px-12 rounded-xl shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105 text-lg"
              >
                <ExternalLink className="mr-2 h-5 w-5" />
                ŞansCasino'ya Kayıt Ol
              </Button>
            </a>
          </div>

          {/* Investment Form */}
          <Card className="backdrop-blur-md bg-white/40 border-white/20 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-800 flex items-center gap-2">
                <Calculator className="h-6 w-6" />
                Yatırım Yap ve Bilet Kazan
              </CardTitle>
              <CardDescription>Yatırım tutarınızı girin ve bilet sayınızı hesaplayın</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleInvestmentSubmit} className="space-y-6">
                {!isLoggedIn ? (
                  <Alert>
                    <AlertDescription>
                      Yatırım yapabilmek için önce{" "}
                      <Link href="/auth/login" className="text-blue-600 hover:underline">
                        giriş yapmalısınız
                      </Link>
                      .
                    </AlertDescription>
                  </Alert>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="sansId">ŞansCasino ID</Label>
                      <Input
                        id="sansId"
                        type="number" // Sadece sayı girişi için type="number"
                        value={sansId}
                        onChange={(e) => setSansId(e.target.value)}
                        placeholder="ŞansCasino ID'nizi girin (sadece sayılar)"
                        className="text-lg py-3"
                        required
                      />
                      <p className="text-xs text-gray-600">
                        Bu ID ile ŞansCasino'da yatırım yaptığınızı kontrol edeceğiz
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="investment">Yatırım Tutarı (TL)</Label>
                      <Input
                        id="investment"
                        type="number"
                        min="1000"
                        step="100"
                        value={investmentAmount}
                        onChange={(e) => setInvestmentAmount(e.target.value)}
                        placeholder="Minimum 1000 TL"
                        className="text-lg py-3"
                      />
                      {investmentAmount && Number.parseFloat(investmentAmount) >= 1000 && (
                        <p className="text-sm text-green-600 font-semibold">
                          🎫 Kazanacağınız bilet sayısı: {calculateTickets(Number.parseFloat(investmentAmount))} adet
                        </p>
                      )}
                    </div>

                    <Button
                      type="submit"
                      disabled={
                        isSubmitting ||
                        !investmentAmount ||
                        Number.parseFloat(investmentAmount) < 1000 ||
                        !sansId ||
                        !/^\d+$/.test(sansId.trim()) // ID'nin sadece sayı olduğunu kontrol et
                      }
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 py-3 text-lg"
                    >
                      {isSubmitting ? "Gönderiliyor..." : "Yatırım Yap"}
                    </Button>
                  </>
                )}

                {submitMessage && (
                  <Alert>
                    <AlertDescription>{submitMessage}</AlertDescription>
                  </Alert>
                )}
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
