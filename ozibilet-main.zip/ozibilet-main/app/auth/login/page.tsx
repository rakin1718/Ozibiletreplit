"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/context/auth-context"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, XCircle } from "lucide-react"
import Image from "next/image"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { login } = useAuth()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Giriş başarısız")
        return
      }

      login(data.user, data.user.role)

      if (data.user.role === "admin") {
        router.push("/admin")
      } else {
        router.push("/dashboard")
      }
    } catch (err: any) {
      setError("Giriş sırasında bir hata oluştu")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100 p-4">
      <Card className="w-full max-w-md bg-white shadow-2xl border-2 border-gray-200">
        <div className="flex justify-center mb-6">
          <Image
            src="/images/ozi-bilet-logo.png"
            alt="Ozi Bilet Logo"
            width={200}
            height={80}
            className="object-contain"
            priority
          />
        </div>
        <CardHeader className="text-center bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
          <CardTitle className="text-3xl font-bold">Giriş Yap</CardTitle>
          <CardDescription className="text-purple-100">Hesabınıza giriş yapın</CardDescription>
        </CardHeader>
        <CardContent className="p-8 bg-white">
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-800 font-semibold text-base">
                E-posta
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="ornek@email.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-gray-50 border-2 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:bg-white text-base py-3"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-gray-800 font-semibold text-base">
                Şifre
              </Label>
              <Input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-50 border-2 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:bg-white text-base py-3"
              />
            </div>
            {error && (
              <Alert variant="destructive" className="bg-red-50 border-2 border-red-300">
                <XCircle className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800 font-bold">Giriş Hatası</AlertTitle>
                <AlertDescription className="text-red-700">{error}</AlertDescription>
              </Alert>
            )}
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 text-lg shadow-lg"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Giriş Yapılıyor...
                </>
              ) : (
                "Giriş Yap"
              )}
            </Button>
          </form>
          <div className="mt-6 text-center text-base">
            <span className="text-gray-700">Hesabınız yok mu? </span>
            <Link href="/auth/register" className="font-bold text-purple-700 hover:text-purple-800 hover:underline">
              Kayıt Ol
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
