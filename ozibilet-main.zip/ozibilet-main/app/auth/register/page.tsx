"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, CheckCircle, XCircle } from "lucide-react"

export default function RegisterPage() {
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email, phone, password }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Kayıt başarısız")
        return
      }

      setSuccess("Kayıt başarılı! Şimdi giriş yapabilirsiniz.")
      setTimeout(() => {
        router.push("/auth/login")
      }, 2000)
    } catch (err: any) {
      setError("Kayıt sırasında bir hata oluştu")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-purple-100 via-pink-100 to-yellow-100 p-4">
      <Card className="w-full max-w-md bg-white shadow-2xl border-2 border-gray-200">
        <CardHeader className="text-center bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
          <CardTitle className="text-3xl font-bold">Kayıt Ol</CardTitle>
          <CardDescription className="text-purple-100">Yeni bir hesap oluşturun</CardDescription>
        </CardHeader>
        <CardContent className="p-8 bg-white">
          <form onSubmit={handleRegister} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="full-name" className="text-gray-800 font-semibold text-base">
                Ad Soyad
              </Label>
              <Input
                id="full-name"
                type="text"
                placeholder="Adınız Soyadınız"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="bg-gray-50 border-2 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:bg-white text-base py-3"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-800 font-semibold text-base">
                E-posta
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="ornek@email.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-gray-50 border-2 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:bg-white text-base py-3"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-gray-800 font-semibold text-base">
                Telefon Numarası
              </Label>
              <Input
                id="phone"
                type="tel"
                placeholder="5xx xxx xx xx"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="bg-gray-50 border-2 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:bg-white text-base py-3"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-gray-800 font-semibold text-base">
                Şifre
              </Label>
              <Input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-50 border-2 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:bg-white text-base py-3"
              />
            </div>
            {error && (
              <Alert variant="destructive" className="bg-red-50 border-2 border-red-300">
                <XCircle className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800 font-bold">Kayıt Hatası</AlertTitle>
                <AlertDescription className="text-red-700">{error}</AlertDescription>
              </Alert>
            )}
            {success && (
              <Alert className="bg-green-50 border-2 border-green-300">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800 font-bold">Başarılı!</AlertTitle>
                <AlertDescription className="text-green-700">{success}</AlertDescription>
              </Alert>
            )}
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 text-lg shadow-lg"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Kayıt Olunuyor...
                </>
              ) : (
                "Kayıt Ol"
              )}
            </Button>
          </form>
          <div className="mt-6 text-center text-base">
            <span className="text-gray-700">Zaten hesabınız var mı? </span>
            <Link href="/auth/login" className="font-bold text-purple-700 hover:text-purple-800 hover:underline">
              Giriş Yap
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
