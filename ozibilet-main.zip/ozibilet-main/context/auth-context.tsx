"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation" // Çıkış sonrası yönlendirme için

interface User {
  id: string
  email: string
  fullName: string
  phone?: string
  role: string
}

interface AuthContextType {
  isLoggedIn: boolean
  user: User | null
  userRole: string | null
  login: (user: User, role: string) => void // Bu fonksiyon artık doğrudan kullanılmayacak, API rotası yönetecek
  logout: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [user, setUser] = useState<User | null>(null)
  const [userRole, setUserRole] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const checkSession = async () => {
      setLoading(true)
      try {
        const response = await fetch("/api/auth/check-session")
        const data = await response.json()

        if (response.ok && data.isLoggedIn) {
          setIsLoggedIn(true)
          setUser(data.user)
          setUserRole(data.user.role)
        } else {
          setIsLoggedIn(false)
          setUser(null)
          setUserRole(null)
        }
      } catch (err) {
        console.error("Oturum kontrol edilirken hata:", err)
        setIsLoggedIn(false)
        setUser(null)
        setUserRole(null)
      } finally {
        setLoading(false)
      }
    }

    checkSession()
    // Oturum durumunu düzenli olarak kontrol etmek isterseniz (isteğe bağlı)
    // const interval = setInterval(checkSession, 60000); // Her dakika kontrol et
    // return () => clearInterval(interval);
  }, [])

  // Bu 'login' fonksiyonu artık doğrudan kullanılmayacak, API rotası tarafından tetiklenecek
  const login = (userData: User, role: string) => {
    setIsLoggedIn(true)
    setUser(userData)
    setUserRole(role)
  }

  const logout = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/auth/logout", { method: "POST" })
      if (!response.ok) {
        console.error("Çıkış yapılırken hata:", await response.json())
      }
    } catch (err) {
      console.error("Çıkış API çağrısı sırasında hata:", err)
    } finally {
      setIsLoggedIn(false)
      setUser(null)
      setUserRole(null)
      setLoading(false)
      router.push("/auth/login") // Çıkış sonrası giriş sayfasına yönlendir
    }
  }

  return (
    <AuthContext.Provider value={{ isLoggedIn, user, userRole, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
