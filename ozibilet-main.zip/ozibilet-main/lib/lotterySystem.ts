import type { EventData } from "./eventData"

export interface LotteryWinner {
  id: string
  userName: string
  userEmail: string
  ticketNumber: string
  prize: number
  prizeDescription: string
  eventName: string
  company: string
  rank: number
}

export interface LotteryParticipant {
  userId: string
  userName: string
  userEmail: string
  tickets: string[]
  company: string
}

// Rastgele çekiliş algoritması
export function conductLottery(participants: LotteryParticipant[], eventData: EventData): LotteryWinner[] {
  const winners: LotteryWinner[] = []
  const allTickets: { ticketNumber: string; participant: LotteryParticipant }[] = []

  // Tüm biletleri topla
  participants.forEach((participant) => {
    participant.tickets.forEach((ticket) => {
      allTickets.push({ ticketNumber: ticket, participant })
    })
  })

  // Biletleri karıştır
  const shuffledTickets = [...allTickets].sort(() => Math.random() - 0.5)
  const usedTickets = new Set<string>()
  const usedParticipants = new Set<string>()

  // Her ödül kategorisi için çekiliş yap
  eventData.prizeStructure.forEach((prizeLevel) => {
    for (let i = 0; i < prizeLevel.count; i++) {
      // Kullanılmamış bilet bul
      const availableTickets = shuffledTickets.filter(
        (item) => !usedTickets.has(item.ticketNumber) && !usedParticipants.has(item.participant.userId),
      )

      if (availableTickets.length === 0) break

      // Rastgele bilet seç
      const randomIndex = Math.floor(Math.random() * availableTickets.length)
      const selectedTicket = availableTickets[randomIndex]

      // Kazananı ekle
      winners.push({
        id: `${Date.now()}-${winners.length}`,
        userName: selectedTicket.participant.userName,
        userEmail: selectedTicket.participant.userEmail,
        ticketNumber: selectedTicket.ticketNumber,
        prize: prizeLevel.prize,
        prizeDescription: `${prizeLevel.description} - ${prizeLevel.prize.toLocaleString("tr-TR")} TL`,
        eventName: eventData.name,
        company: eventData.company,
        rank: prizeLevel.rank,
      })

      // Kullanılan bilet ve katılımcıyı işaretle
      usedTickets.add(selectedTicket.ticketNumber)
      usedParticipants.add(selectedTicket.participant.userId)
    }
  })

  return winners.sort((a, b) => a.rank - b.rank)
}

// Çekiliş sonuçlarını banner formatına çevir
export function formatWinnersForBanner(winners: LotteryWinner[]) {
  return winners.map((winner) => ({
    id: winner.id,
    userName: winner.userName,
    ticketNumber: winner.ticketNumber,
    prize: winner.prizeDescription,
    eventName: winner.eventName,
  }))
}
