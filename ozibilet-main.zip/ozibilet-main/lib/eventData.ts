interface PrizeStructure {
  count: number
  prize: number
  description: string
}

interface Event {
  id: string
  name: string
  company: string
  slug: string
  logo: string
  startDate: string
  endDate: string
  totalPrize: number
  prizeStructure: PrizeStructure[]
  isActive: boolean
}

const events: Event[] = [
  {
    id: "1",
    name: "Büyük Çekiliş",
    company: "Şanscasino",
    slug: "sanscasino",
    logo: "/images/sanscasino-logo.png",
    startDate: "2024-01-01T00:00:00Z",
    endDate: "2024-12-31T23:59:59Z",
    totalPrize: 100000,
    prizeStructure: [
      { count: 1, prize: 50000, description: "Büyük Ödül" },
      { count: 2, prize: 10000, description: "İkinci Ödül" },
      { count: 5, prize: 5000, description: "Üçüncü Ödül" },
    ],
    isActive: true,
  },
]

export function getAllEvents(): Event[] {
  return events
}

export function getAllActiveEvents(): Event[] {
  return events.filter((event) => event.isActive)
}

export function getEventBySlug(slug: string): Event | undefined {
  return events.find((event) => event.slug === slug)
}
