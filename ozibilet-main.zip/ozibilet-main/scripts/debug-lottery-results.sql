-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Önce mevcut verileri kontrol edelim

-- 1. Mevcut lottery_results tablosundaki tüm verileri göster
SELECT * FROM public.lottery_results ORDER BY created_at DESC;

-- 2. Eğer veri yoksa, tabloyu temizle ve yeniden ekle
DELETE FROM public.lottery_results;

-- 3. Güncellenmiş kazanan biletleri ekle
INSERT INTO public.lottery_results (user_name, ticket_number, prize, event_name, created_at) VALUES
-- Büyük ödül kazananları
('ŞansCasino Üyesi', '89024968', '50.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '79707490', '30.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '93090064', '15.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '27717995', '10.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '33192366', '5.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),

-- 2.000 TL kazananları (güncellenmiş liste)
('ŞansCasino Üyesi', '56162266', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '32549388', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '73141479', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '49209426', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '72967992', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '86291486', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '27452358', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '97181015', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '78399609', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('ŞansCasino Üyesi', '72848225', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW());

-- 4. Eklenen verileri kontrol et
SELECT COUNT(*) as total_winners FROM public.lottery_results;
SELECT * FROM public.lottery_results ORDER BY 
  CASE 
    WHEN prize = '50.000 TL' THEN 1
    WHEN prize = '30.000 TL' THEN 2
    WHEN prize = '15.000 TL' THEN 3
    WHEN prize = '10.000 TL' THEN 4
    WHEN prize = '5.000 TL' THEN 5
    ELSE 6
  END;
