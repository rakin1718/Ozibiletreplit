-- Bu scripti Supabase SQL Editor'da çalıştırmalısınız.
-- Bu script, mevcut tabloları siler ve doğru şemayla yeniden oluşturur.

-- Foreign key bağımlılıkları nedeniyle doğru sırayla silin
DROP TABLE IF EXISTS public.investments CASCADE;
DROP TABLE IF EXISTS public.admin_users CASCADE;
DROP TABLE IF EXISTS public.users CASCADE;

-- 1) Gerekli eklenti (UUID oluşturmak için)
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2) USERS tablosu
CREATE TABLE public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name      TEXT NOT NULL,
  email          TEXT UNIQUE NOT NULL,
  phone          TEXT NOT NULL,
  password_hash  TEXT NOT NULL,
  created_at     TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3) INVESTMENTS tablosu
CREATE TABLE public.investments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  sans_username  TEXT NOT NULL,
  amount         DECIMAL(10,2) NOT NULL,
  status         TEXT DEFAULT 'Bekliyor'
                 CHECK (status IN ('Bekliyor','Onaylandı','Reddedildi')),
  tickets        JSONB,
  created_at     TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  approved_at    TIMESTAMPTZ
);

-- 4) ADMIN_USERS tablosu
CREATE TABLE public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email          TEXT UNIQUE NOT NULL,
  password_hash  TEXT NOT NULL,
  created_at     TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5) Varsayılan admin kullanıcısını ekle veya şifresini güncelle (şifre: admin123)
INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi') -- 'admin123' şifresinin doğru bcrypt hash'i
ON CONFLICT (email) DO UPDATE SET
  password_hash = EXCLUDED.password_hash;
