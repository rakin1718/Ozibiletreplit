-- Bu scripti Supabase SQL Editor'da çalıştırın
-- admin@ozibilet.com şifresini 'admin123' olarak ayarlar

UPDATE public.admin_users 
SET password_hash = '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
WHERE email = 'admin@ozibilet.com';

-- Eğer admin kullanıcısı yoksa ekle
INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi')
ON CONFLICT (email) DO UPDATE SET
  password_hash = EXCLUDED.password_hash;
