-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Önce mevcut kullanıcıları kontrol edelim ve kazanan biletlere user_id ekleyelim

-- 1. Mevcut kullanıcıları göster
SELECT id, full_name, email FROM public.users ORDER BY created_at DESC LIMIT 20;

-- 2. Mevcut lottery_results'ı temizle
DELETE FROM public.lottery_results;

-- 3. Kullanıcı ID'leri ile birlikte kazanan biletleri ekle
-- (Eğer yeterli kullanıcı yoksa, bazıları NULL kalabilir)
WITH user_ids AS (
  SELECT id, full_name, ROW_NUMBER() OVER (ORDER BY created_at) as rn 
  FROM public.users 
  LIMIT 15
)
INSERT INTO public.lottery_results (user_id, user_name, ticket_number, prize, event_name, created_at) 
SELECT 
  CASE 
    WHEN ROW_NUMBER() OVER (ORDER BY prize_order) <= (SELECT COUNT(*) FROM user_ids) 
    THEN (SELECT id FROM user_ids WHERE rn = ROW_NUMBER() OVER (ORDER BY prize_order))
    ELSE NULL 
  END as user_id,
  CASE 
    WHEN ROW_NUMBER() OVER (ORDER BY prize_order) <= (SELECT COUNT(*) FROM user_ids) 
    THEN (SELECT full_name FROM user_ids WHERE rn = ROW_NUMBER() OVER (ORDER BY prize_order))
    ELSE 'ŞansCasino Üyesi' 
  END as user_name,
  ticket_number,
  prize,
  event_name,
  created_at
FROM (
  VALUES 
    -- Büyük ödül kazananları (öncelik sırasına göre)
    ('89024968', '50.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 1),
    ('79707490', '30.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 2),
    ('93090064', '15.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 3),
    ('27717995', '10.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 4),
    ('33192366', '5.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 5),
    
    -- 2.000 TL kazananları
    ('56162266', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 6),
    ('32549388', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 7),
    ('73141479', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 8),
    ('49209426', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 9),
    ('72967992', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 10),
    ('86291486', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 11),
    ('27452358', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 12),
    ('97181015', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 13),
    ('78399609', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 14),
    ('72848225', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW(), 15)
) AS winners(ticket_number, prize, event_name, created_at, prize_order)
ORDER BY prize_order;

-- 4. Sonuçları kontrol et
SELECT 
  lr.user_id,
  lr.user_name,
  lr.ticket_number,
  lr.prize,
  lr.event_name,
  u.email as user_email
FROM public.lottery_results lr
LEFT JOIN public.users u ON lr.user_id = u.id
ORDER BY 
  CASE 
    WHEN lr.prize = '50.000 TL' THEN 1
    WHEN lr.prize = '30.000 TL' THEN 2
    WHEN lr.prize = '15.000 TL' THEN 3
    WHEN lr.prize = '10.000 TL' THEN 4
    WHEN lr.prize = '5.000 TL' THEN 5
    ELSE 6
  END;

-- 5. Toplam kazanan sayısını göster
SELECT COUNT(*) as total_winners FROM public.lottery_results;
