-- Updated database schema with username field
-- Bu scripti Supabase SQL Editor'da çalıştırmalısınız.
-- Eğer tablolar zaten varsa, DROP TABLE komutlarını dikkatli kullanın veya kaldırın.

-- Mevcut tabloları sil (sadece geliştirme ortamında güvenli)
DROP TABLE IF EXISTS investments;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS admin_users;

-- Create users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- UUID olarak değiştirildi
    full_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create investments table
CREATE TABLE investments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- UUID olarak değiştirildi
    user_id UUID NOT NULL REFERENCES users(id), -- users tablosuna referans
    sans_username TEXT NOT NULL, -- ŞansCasino kullanıcı adı (yatırım sırasında girilen)
    amount DECIMAL(10,2) NOT NULL,
    status TEXT DEFAULT 'Bekliyor' CHECK (status IN ('Bekliyor', 'Onaylandı', 'Reddedildi')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP WITH TIME ZONE,
    tickets JSONB -- JSON array of ticket numbers
);

-- Create admin users table
CREATE TABLE admin_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- UUID olarak değiştirildi
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (gerçek hash kullanın)
-- Bu hash 'admin123' şifresine aittir. Kendi güvenli şifrenizi kullanın.
INSERT INTO admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi')
ON CONFLICT (email) DO NOTHING; -- Eğer zaten varsa ekleme

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_investments_user_id ON investments(user_id);
CREATE INDEX IF NOT EXISTS idx_investments_sans_username ON investments(sans_username);
CREATE INDEX IF NOT EXISTS idx_investments_status ON investments(status);
