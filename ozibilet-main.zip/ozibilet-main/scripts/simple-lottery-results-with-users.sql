-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Basit yöntem: Mevcut kullanıcıları manuel olarak eşleştir

-- 1. Önce mevcut kullanıcıları listele (ID'lerini not al)
SELECT id, full_name, email FROM public.users ORDER BY created_at DESC;

-- 2. Mevcut lottery_results'ı temizle
DELETE FROM public.lottery_results;

-- 3. Manuel olarak user_id'leri ile birlikte ekle
-- (Aşağıdaki user_id'leri yukarıdaki sorgudan aldığın gerçek ID'lerle değiştir)
INSERT INTO public.lottery_results (user_id, user_name, ticket_number, prize, event_name, created_at) VALUES

-- Büyük ödül kazananları (user_id'leri gerçek kullanıcı ID'leri ile değiştir)
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 0), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 0), '89024968', '50.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 1), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 1), '79707490', '30.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 2), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 2), '93090064', '15.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 3), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 3), '27717995', '10.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 4), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 4), '33192366', '5.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),

-- 2.000 TL kazananları
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 5), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 5), '56162266', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 6), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 6), '32549388', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 7), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 7), '73141479', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 8), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 8), '49209426', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
((SELECT id FROM public.users ORDER BY created_at LIMIT 1 OFFSET 9), (SELECT full_name FROM public.users ORDER BY created_at LIMIT 1 OFFSET 9), '72967992', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),

-- Eğer yeterli kullanıcı yoksa, kalan kazananlar için NULL user_id
(NULL, 'ŞansCasino Üyesi', '86291486', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '27452358', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '97181015', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '78399609', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '72848225', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW());

-- 4. Sonuçları kontrol et
SELECT 
  lr.user_id,
  lr.user_name,
  lr.ticket_number,
  lr.prize,
  u.email as user_email
FROM public.lottery_results lr
LEFT JOIN public.users u ON lr.user_id = u.id
ORDER BY 
  CASE 
    WHEN lr.prize = '50.000 TL' THEN 1
    WHEN lr.prize = '30.000 TL' THEN 2
    WHEN lr.prize = '15.000 TL' THEN 3
    WHEN lr.prize = '10.000 TL' THEN 4
    WHEN lr.prize = '5.000 TL' THEN 5
    ELSE 6
  END;
