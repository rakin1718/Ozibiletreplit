-- Bu scripti Supabase SQL Editor'da çalıştırın.
-- admin@ozibilet.com kullanıcısının şifresini 'admin123' şifresinin doğru bcrypt hash'i ile günceller.
-- Eğer admin kullanıcısı yoksa, bu satır onu ekler.

INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi') -- 'admin123' şifresinin doğru bcrypt hash'i
ON CONFLICT (email) DO UPDATE SET
  password_hash = EXCLUDED.password_hash;
