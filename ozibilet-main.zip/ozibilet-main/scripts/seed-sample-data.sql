-- Insert sample users
INSERT OR IGNORE INTO users (id, full_name, email, phone, password_hash, created_at, ip_address) VALUES
(1, 'Ahmet Yılmaz', 'ahmet@email.com', '05321234567', '$2b$10$sample_hash', '2025-01-08 10:00:00', '192.168.1.1'),
(2, 'Fatma Kaya', 'fatma@email.com', '05339876543', '$2b$10$sample_hash', '2025-01-10 14:30:00', '192.168.1.2'),
(3, 'Mehmet Demir', 'mehmet@email.com', '05345556677', '$2b$10$sample_hash', '2025-01-12 09:15:00', '192.168.1.3');

-- Insert sample investments
INSERT OR IGNORE INTO investments (id, user_id, amount, status, created_at, approved_at, tickets) VALUES
(1, 1, 5000.00, 'Onaylandı', '2025-01-10 15:00:00', '2025-01-10 16:00:00', '["54879320","87654321","12345678","98765432","11223344"]'),
(2, 2, 3000.00, 'Bekliyor', '2025-01-12 11:00:00', NULL, NULL),
(3, 3, 2000.00, 'Bekliyor', '2025-01-13 13:00:00', NULL, NULL),
(4, 1, 1500.00, 'Reddedildi', '2025-01-08 16:00:00', NULL, NULL);
