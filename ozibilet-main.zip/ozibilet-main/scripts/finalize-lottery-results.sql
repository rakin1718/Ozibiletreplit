-- Bu scripti Supabase SQL Editor'da çalıştırın
-- ŞansCasino çekilişinin kazanan biletlerini ekler

-- Önce mevcut test verilerini temizle
DELETE FROM public.lottery_results WHERE event_name LIKE '%ŞansCasino%';

-- Kazanan biletleri ekle - Büyük Ödüller
INSERT INTO public.lottery_results (user_name, ticket_number, prize, event_name, created_at) VALUES
('Kazanan Üye', '89024968', '50.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '79707490', '30.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '93090064', '15.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '27717995', '10.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '33192366', '5.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),

-- 2.000 TL Kazananlar
('Kazanan Üye', '45530330', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '56162266', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '32549388', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '73141479', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '49209426', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '86291486', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '27452358', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '96490165', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '97181015', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '78399609', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Üye', '72848225', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW());
