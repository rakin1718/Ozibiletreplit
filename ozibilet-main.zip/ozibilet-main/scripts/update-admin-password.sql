-- Bu scripti Supabase SQL Editor'da çalıştırmalısınız.

-- Varsayılan admin kullanıcısını ekle veya şifresini güncelle
-- E-posta: admin@ozibilet.com
-- Şifre: admin1234 (Bu şifrenin bcrypt hash'i aşağıdadır)
INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', '$2a$10$2j.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.
