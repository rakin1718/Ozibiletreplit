-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Basit ve çalışan yöntem

-- 1. Önce mevcut kullanıcıları göster (kaç tane olduğunu görmek için)
SELECT COUNT(*) as total_users FROM public.users;
SELECT id, full_name, email FROM public.users ORDER BY created_at LIMIT 15;

-- 2. Mevcut lottery_results'ı temizle
DELETE FROM public.lottery_results;

-- 3. Kullanıcıları sırayla eşleştirerek kazananları ekle
DO $$
DECLARE
    user_ids UUID[];
    user_names TEXT[];
    i INTEGER := 1;
BEGIN
    -- Kullanıcı ID'lerini ve isimlerini array'e al
    SELECT ARRAY_AGG(id ORDER BY created_at), ARRAY_AGG(full_name ORDER BY created_at) 
    INTO user_ids, user_names 
    FROM public.users 
    LIMIT 15;
    
    -- Büyük ödül kazananları
    INSERT INTO public.lottery_results (user_id, user_name, ticket_number, prize, event_name, created_at) VALUES
    (CASE WHEN array_length(user_ids, 1) >= 1 THEN user_ids[1] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 1 THEN user_names[1] ELSE 'ŞansCasino Üyesi' END, 
     '89024968', '50.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 2 THEN user_ids[2] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 2 THEN user_names[2] ELSE 'ŞansCasino Üyesi' END, 
     '79707490', '30.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 3 THEN user_ids[3] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 3 THEN user_names[3] ELSE 'ŞansCasino Üyesi' END, 
     '93090064', '15.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 4 THEN user_ids[4] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 4 THEN user_names[4] ELSE 'ŞansCasino Üyesi' END, 
     '27717995', '10.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 5 THEN user_ids[5] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 5 THEN user_names[5] ELSE 'ŞansCasino Üyesi' END, 
     '33192366', '5.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    -- 2.000 TL kazananları
    (CASE WHEN array_length(user_ids, 1) >= 6 THEN user_ids[6] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 6 THEN user_names[6] ELSE 'ŞansCasino Üyesi' END, 
     '56162266', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 7 THEN user_ids[7] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 7 THEN user_names[7] ELSE 'ŞansCasino Üyesi' END, 
     '32549388', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 8 THEN user_ids[8] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 8 THEN user_names[8] ELSE 'ŞansCasino Üyesi' END, 
     '73141479', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 9 THEN user_ids[9] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 9 THEN user_names[9] ELSE 'ŞansCasino Üyesi' END, 
     '49209426', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 10 THEN user_ids[10] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 10 THEN user_names[10] ELSE 'ŞansCasino Üyesi' END, 
     '72967992', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 11 THEN user_ids[11] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 11 THEN user_names[11] ELSE 'ŞansCasino Üyesi' END, 
     '86291486', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 12 THEN user_ids[12] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 12 THEN user_names[12] ELSE 'ŞansCasino Üyesi' END, 
     '27452358', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 13 THEN user_ids[13] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 13 THEN user_names[13] ELSE 'ŞansCasino Üyesi' END, 
     '97181015', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 14 THEN user_ids[14] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 14 THEN user_names[14] ELSE 'ŞansCasino Üyesi' END, 
     '78399609', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
     
    (CASE WHEN array_length(user_ids, 1) >= 15 THEN user_ids[15] ELSE NULL END, 
     CASE WHEN array_length(user_names, 1) >= 15 THEN user_names[15] ELSE 'ŞansCasino Üyesi' END, 
     '72848225', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW());
     
END $$;

-- 4. Sonuçları kontrol et
SELECT 
  lr.user_id,
  lr.user_name,
  lr.ticket_number,
  lr.prize,
  u.email as user_email
FROM public.lottery_results lr
LEFT JOIN public.users u ON lr.user_id = u.id
ORDER BY 
  CASE 
    WHEN lr.prize = '50.000 TL' THEN 1
    WHEN lr.prize = '30.000 TL' THEN 2
    WHEN lr.prize = '15.000 TL' THEN 3
    WHEN lr.prize = '10.000 TL' THEN 4
    WHEN lr.prize = '5.000 TL' THEN 5
    ELSE 6
  END;

-- 5. Toplam kazanan sayısını göster
SELECT COUNT(*) as total_winners FROM public.lottery_results;
