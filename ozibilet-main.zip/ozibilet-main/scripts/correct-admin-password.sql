-- Bu scripti Supabase SQL Editor'da çalıştırın
-- admin@ozibilet.com şifresini gerçek 'admin123' hash'i ile günceller

UPDATE public.admin_users 
SET password_hash = '$2a$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPJFflsy2'
WHERE email = 'admin@ozibilet.com';

-- Eğer admin kullanıcısı yoksa ekle
INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', '$2a$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPJFflsy2')
ON CONFLICT (email) DO UPDATE SET
  password_hash = EXCLUDED.password_hash;
