-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Lottery results tablosunu gerçek kullanıcı verileriyle düzelt

-- 1. Önce lottery_results tablosunu tamamen temizle
DELETE FROM public.lottery_results;

-- 2. Gerçek kullanıcı biletlerini kontrol et ve kazanan biletlerle eşleştir
WITH winning_tickets AS (
    SELECT ticket, prize, rank FROM (VALUES
        ('89024968', '50.000 TL', 1),
        ('79707490', '30.000 TL', 2),
        ('93090064', '15.000 TL', 3),
        ('27717995', '10.000 TL', 4),
        ('33192366', '5.000 TL', 5),
        ('56162266', '2.000 TL', 6),
        ('32549388', '2.000 TL', 7),
        ('73141479', '2.000 TL', 8),
        ('49209426', '2.000 TL', 9),
        ('72967992', '2.000 TL', 10),
        ('86291486', '2.000 TL', 11),
        ('27452358', '2.000 TL', 12),
        ('97181015', '2.000 TL', 13),
        ('78399609', '2.000 TL', 14),
        ('72848225', '2.000 TL', 15)
    ) AS t(ticket, prize, rank)
),
user_tickets AS (
    SELECT 
        u.id as user_id,
        u.full_name,
        u.email,
        jsonb_array_elements_text(i.tickets) as ticket_number
    FROM public.users u
    JOIN public.investments i ON u.id = i.user_id
    WHERE i.status = 'Onaylandı' 
    AND i.tickets IS NOT NULL 
    AND jsonb_array_length(i.tickets) > 0
)
INSERT INTO public.lottery_results (user_id, user_name, ticket_number, prize, event_name, created_at)
SELECT 
    COALESCE(ut.user_id, NULL) as user_id,
    COALESCE(ut.full_name, 'ŞansCasino Üyesi') as user_name,
    wt.ticket as ticket_number,
    wt.prize,
    'ŞansCasino Büyük Çekiliş' as event_name,
    NOW() as created_at
FROM winning_tickets wt
LEFT JOIN user_tickets ut ON wt.ticket = ut.ticket_number
ORDER BY wt.rank;

-- 3. Sonuçları kontrol et
SELECT 
    lr.user_id,
    lr.user_name,
    lr.ticket_number,
    lr.prize,
    u.email,
    CASE 
        WHEN lr.user_id IS NOT NULL THEN '✅ GERÇEK KULLANICI'
        ELSE '❌ BİLET SAHİBİ YOK'
    END as durum
FROM public.lottery_results lr
LEFT JOIN public.users u ON lr.user_id = u.id
ORDER BY 
    CASE 
        WHEN lr.prize = '50.000 TL' THEN 1
        WHEN lr.prize = '30.000 TL' THEN 2
        WHEN lr.prize = '15.000 TL' THEN 3
        WHEN lr.prize = '10.000 TL' THEN 4
        WHEN lr.prize = '5.000 TL' THEN 5
        ELSE 6
    END;

-- 4. Özet bilgi
SELECT 
    COUNT(*) as toplam_kazanan,
    COUNT(user_id) as gercek_kullanici_kazanan,
    COUNT(*) - COUNT(user_id) as bilet_sahibi_olmayan
FROM public.lottery_results;
