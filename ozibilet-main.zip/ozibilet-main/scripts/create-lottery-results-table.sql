CREATE TABLE IF NOT EXISTS public.lottery_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id),
  user_name TEXT NOT NULL,
  ticket_number TEXT NOT NULL,
  prize TEXT NOT NULL,
  event_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- created_at sütununda daha hızlı arama yapmak için bir indeks ekler
CREATE INDEX IF NOT EXISTS idx_lottery_results_created_at ON public.lottery_results (created_at DESC);
