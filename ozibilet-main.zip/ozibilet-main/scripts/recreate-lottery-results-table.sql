-- DİKKAT: Bu komut, mevcut 'lottery_results' tablosunu ve içindeki TÜM VERİLERİ silecektir!
-- Eğer tablo yoksa, hata vermeden devam edecektir.
DROP TABLE IF EXISTS public.lottery_results CASCADE;

-- 'lottery_results' tablosunu doğru şema ile yeniden oluşturur
CREATE TABLE public.lottery_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id), -- users tablosuna referans
  user_name TEXT NOT NULL,
  ticket_number TEXT NOT NULL,
  prize TEXT NOT NULL,
  event_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- created_at sütununda daha hızlı arama yapmak için bir indeks ekler
CREATE INDEX IF NOT EXISTS idx_lottery_results_created_at ON public.lottery_results (created_at DESC);
