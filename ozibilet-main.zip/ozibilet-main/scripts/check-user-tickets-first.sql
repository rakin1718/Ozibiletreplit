-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Önce hangi kullanıcının hangi biletleri olduğunu görelim

-- 1. Tüm kullanıcıları ve biletlerini listele
SELECT 
    u.id as user_id,
    u.full_name,
    u.email,
    i.amount,
    i.status,
    i.tickets,
    i.created_at
FROM public.users u
LEFT JOIN public.investments i ON u.id = i.user_id
WHERE i.status = 'Onaylandı' AND i.tickets IS NOT NULL
ORDER BY u.created_at;

-- 2. Biletleri tek tek görmek için (her bilet ayrı satırda)
SELECT 
    u.id as user_id,
    u.full_name,
    u.email,
    jsonb_array_elements_text(i.tickets) as ticket_number,
    i.amount,
    i.created_at
FROM public.users u
JOIN public.investments i ON u.id = i.user_id
WHERE i.status = 'Onaylandı' AND i.tickets IS NOT NULL
ORDER BY u.full_name, ticket_number;

-- 3. Kazanan bilet numaralarını kontrol et
WITH winning_tickets AS (
    SELECT unnest(ARRAY[
        '89024968', '79707490', '93090064', '27717995', '33192366',
        '56162266', '32549388', '73141479', '49209426', '72967992',
        '86291486', '27452358', '97181015', '78399609', '72848225'
    ]) as winning_ticket
),
user_tickets AS (
    SELECT 
        u.id as user_id,
        u.full_name,
        u.email,
        jsonb_array_elements_text(i.tickets) as ticket_number
    FROM public.users u
    JOIN public.investments i ON u.id = i.user_id
    WHERE i.status = 'Onaylandı' AND i.tickets IS NOT NULL
)
SELECT 
    wt.winning_ticket,
    ut.user_id,
    ut.full_name,
    ut.email,
    CASE 
        WHEN ut.user_id IS NOT NULL THEN 'GERÇEK KULLANICI'
        ELSE 'BİLET SAHİBİ YOK'
    END as durum
FROM winning_tickets wt
LEFT JOIN user_tickets ut ON wt.winning_ticket = ut.ticket_number
ORDER BY wt.winning_ticket;
