-- Bu scripti Supabase SQL Editor'da çalıştırın
-- En basit yöntem - Manuel ID girişi

-- 1. Önce kullanıcıları listele ve ID'lerini not al
SELECT id, full_name, email FROM public.users ORDER BY created_at LIMIT 15;

-- 2. Mevcut lottery_results'ı temizle
DELETE FROM public.lottery_results;

-- 3. Manuel olarak ekle (ID'leri yukarıdaki sorgudan kopyala)
-- Örnek: İlk kullanıcının ID'si 'abc123' ise, onu aşağıya yaz

INSERT INTO public.lottery_results (user_id, user_name, ticket_number, prize, event_name, created_at) VALUES

-- BÜYÜK ÖDÜLLER - Aşağıdaki 'USER_ID_1', 'USER_ID_2' kısımlarını gerçek ID'lerle değiştir
('USER_ID_1', 'Kullanıcı Adı 1', '89024968', '50.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_2', 'Kullanıcı Adı 2', '79707490', '30.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_3', 'Kullanıcı Adı 3', '93090064', '15.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_4', 'Kullanıcı Adı 4', '27717995', '10.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_5', 'Kullanıcı Adı 5', '33192366', '5.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),

-- 2.000 TL KAZANANLAR
('USER_ID_6', 'Kullanıcı Adı 6', '56162266', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_7', 'Kullanıcı Adı 7', '32549388', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_8', 'Kullanıcı Adı 8', '73141479', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_9', 'Kullanıcı Adı 9', '49209426', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('USER_ID_10', 'Kullanıcı Adı 10', '72967992', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),

-- Eğer yeterli kullanıcı yoksa NULL bırak
(NULL, 'ŞansCasino Üyesi', '86291486', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '27452358', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '97181015', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '78399609', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
(NULL, 'ŞansCasino Üyesi', '72848225', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW());

-- 4. Kontrol et
SELECT * FROM public.lottery_results ORDER BY 
  CASE 
    WHEN prize = '50.000 TL' THEN 1
    WHEN prize = '30.000 TL' THEN 2
    WHEN prize = '15.000 TL' THEN 3
    WHEN prize = '10.000 TL' THEN 4
    WHEN prize = '5.000 TL' THEN 5
    ELSE 6
  END;
