-- 1) Gerekli eklenti
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2) USERS tablosu
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name      TEXT NOT NULL,
  email          TEXT UNIQUE NOT NULL,
  phone          TEXT NOT NULL,
  password_hash  TEXT NOT NULL,
  created_at     TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3) INVESTMENTS tablosu
CREATE TABLE IF NOT EXISTS public.investments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  sans_username  TEXT NOT NULL,
  amount         DECIMAL(10,2) NOT NULL,
  status         TEXT DEFAULT 'Bekliyor'
                 CHECK (status IN ('Bekliyor','Onaylandı','Reddedildi')),
  tickets        JSONB,
  created_at     TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  approved_at    TIMESTAMPTZ
);

-- 4) ADMIN_USERS tablosu
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email          TEXT UNIQUE NOT NULL,
  password_hash  TEXT NOT NULL,
  created_at     TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Varsayılan admin
INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com',
        '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi')  -- admin123
ON CONFLICT (email) DO NOTHING;
