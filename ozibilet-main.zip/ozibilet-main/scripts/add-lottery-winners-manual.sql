-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Manuel olarak kazanan bilet numaralarını lottery_results tablosuna ekler

-- Önce mevcut kazananları temizle (eğer test verisi varsa)
-- DELETE FROM public.lottery_results WHERE event_name = 'ŞansCasino';

-- Kazanan biletleri ekle
INSERT INTO public.lottery_results (user_name, ticket_number, prize, event_name, created_at) VALUES
-- Büyük Ödüller
('Kazanan Kullanıcı', '89024968', '50.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '79707490', '30.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '93090064', '15.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '27717995', '10.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '33192366', '5.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),

-- 2.000 TL Kazananlar
('Kazanan Kullanıcı', '45530330', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '56162266', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '32549388', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '73141479', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '49209426', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '86291486', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '27452358', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '96490165', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '97181015', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '78399609', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW()),
('Kazanan Kullanıcı', '72848225', '2.000 TL', 'ŞansCasino Büyük Çekiliş', NOW());
