-- Bu scripti Supabase SQL Editor'da çalıştırın
-- investments tablosuna company kolonu ekler

ALTER TABLE public.investments 
ADD COLUMN IF NOT EXISTS company TEXT DEFAULT 'ŞansCasino';

-- Mevcut kayıtları güncelle
UPDATE public.investments 
SET company = 'ŞansCasino' 
WHERE company IS NULL;
