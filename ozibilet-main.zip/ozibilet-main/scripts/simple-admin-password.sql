-- Bu scripti Supabase SQL Editor'da çalıştırın
-- Şifreyi düz metin olarak admin123 yapar

UPDATE public.admin_users 
SET password_hash = 'admin123'
WHERE email = 'admin@ozibilet.com';

-- Eğer admin kullanıcısı yoksa ekle
INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', 'admin123')
ON CONFLICT (email) DO UPDATE SET
  password_hash = EXCLUDED.password_hash;
