-- DİKKAT: Bu script, admin@ozibilet.com kullanıcısının şifresini veritabanında düz metin olarak 'admin123' yapar.
-- Bu, güvenlik açısından ÖNERİLMEYEN bir yöntemdir ve sadece geliştirme/test amaçlı kullanılmalıdır.
-- Üretim ortamında ASLA düz metin şifre kullanmayın!

UPDATE public.admin_users 
SET password_hash = 'admin123'
WHERE email = 'admin@ozibilet.com';

-- Eğer admin kullanıcısı yoksa, bu satır onu ekler.
INSERT INTO public.admin_users (email, password_hash)
VALUES ('admin@ozibilet.com', 'admin123')
ON CONFLICT (email) DO UPDATE SET
  password_hash = EXCLUDED.password_hash;
